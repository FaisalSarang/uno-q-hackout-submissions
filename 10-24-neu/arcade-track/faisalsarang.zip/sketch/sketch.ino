#include <Arduino.h>
#include <Arduino_RouterBridge.h>
#include <Arduino_Modulino.h>
#include <DIYables_TFT_Touch_Shield.h>
#include <math.h>
#include "video_protocol.h"
#include "game_types.h"

#if !defined(ARDUINO_UNO_Q)
#error "Select Arduino UNO Q for this starter."
#endif

// Hosts select the controller fitted to their preassembled consoles.
#ifndef ARCADE_TFT_HX8357D
#define ARCADE_TFT_HX8357D 1
#endif
#if ARCADE_TFT_HX8357D
DIYables_TFT_HX8357D_Shield display;
#else
DIYables_TFT_RM68140_Shield display;
#endif

const uint8_t BUTTONS_ADDRESS = 0x3E;
const uint8_t JOYSTICK_ADDRESS = 0x2C;
ModulinoButtons buttons(BUTTONS_ADDRESS);
ModulinoMovement movement;
bool movementReady = false;

const uint16_t TFT_BLACK = 0x0000;
const uint16_t TFT_WHITE = 0xFFFF;
const uint16_t TFT_CYAN = 0x07FF;
unsigned long lastFrameAt = 0;
bool waiting = true;
bool roomReady = false;
int videoSession = 0;
int nextVideoSession = 0;
int lastX = -1;
int lastY = -1;

bool readPacket(uint8_t address, uint8_t payload[3]) {
  // update() means "changed", not "read succeeded"; reject incomplete wire packets.
  int count = Wire1.requestFrom(address, (uint8_t)4);
  if (count != 4) {
    while (Wire1.available()) Wire1.read();
    return false;
  }
  Wire1.read();  // Modulino pinstrap address precedes the three input bytes.
  for (int i = 0; i < 3; ++i) payload[i] = Wire1.read();
  return true;
}

String readInputs() {
  uint8_t buttonData[3] = {};
  uint8_t stickData[3] = {};
  bool buttonsOk = readPacket(BUTTONS_ADDRESS, buttonData);
  bool joystickOk = readPacket(JOYSTICK_ADDRESS, stickData);
  bool movementOk = movementReady && movement.update();
  float ax = movementOk ? movement.getX() : 0;
  float ay = movementOk ? movement.getY() : 0;
  float az = movementOk ? movement.getZ() : 0;
  movementOk = movementOk && isfinite(ax) && isfinite(ay) && isfinite(az);
  int connected = (buttonsOk ? 1 : 0) | (joystickOk ? 2 : 0) | (movementOk ? 4 : 0);
  int pressed = 0;
  if (buttonsOk) {
    for (int i = 0; i < 3; ++i) if (buttonData[i]) pressed |= 1 << i;
    buttons.setLeds(buttonData[0], buttonData[1], buttonData[2]);
  }
  if (joystickOk && stickData[2]) pressed |= 8;
  char json[180];
  snprintf(json, sizeof(json),
           "{\"video\":%d,\"connected\":%d,\"buttons\":%d,\"x\":%d,\"y\":%d,"
           "\"ax\":%d,\"ay\":%d,\"az\":%d}",
           videoSession, connected, pressed,
           joystickOk ? 128 - (int)stickData[0] : 0,
           joystickOk ? 128 - (int)stickData[1] : 0,
           movementOk ? (int)(constrain(ax, -16.0f, 16.0f) * 1000) : 0,
           movementOk ? (int)(constrain(ay, -16.0f, 16.0f) * 1000) : 0,
           movementOk ? (int)(constrain(az, -16.0f, 16.0f) * 1000) : 0);
  return String(json);
}

void textLine(int y, const char* text) {
  display.setCursor(12, y);
  display.setTextColor(TFT_WHITE, TFT_BLACK);
  display.print(text);
}

void showWaiting() {
  if (videoSession) {
    videoSession = 0;
    display.fillScreen(TFT_BLACK);
    textLine(10, "UNO Q arcade starter");
    display.drawRect(12, 160, 456, 148, TFT_WHITE);
  }
  display.fillRect(12, 36, 456, 112, TFT_BLACK);
  textLine(36, "Waiting for App Lab...");
  if (lastX >= 0) display.fillCircle(lastX, lastY, 6, TFT_BLACK);
  lastX = -1;
  waiting = true;
  roomReady = false;  // Python resends the room when game_frame reports 0.
}

bool drawFrame(int x, int y, int pressed, int ax, int ay, int az, int connected) {
  if (videoSession) return false;  // RetroArch owns the display until release/timeout.
  // Bound every RPC input before using it for drawing or bit masks.
  x = constrain(x, 20, 460);
  y = constrain(y, 168, 300);
  pressed &= 15;
  connected &= 7;
  if (!(connected & 1)) pressed &= 8;
  if (!(connected & 2)) { pressed &= 7; x = 240; y = 234; }
  if (!(connected & 4)) { ax = 0; ay = 0; az = 0; }
  ax = constrain(ax, -16000, 16000);
  ay = constrain(ay, -16000, 16000);
  az = constrain(az, -16000, 16000);
  if (waiting) display.fillRect(12, 36, 456, 112, TFT_BLACK);
  char line[40];
  snprintf(line, sizeof(line), "Buttons:%s Stick:%s IMU:%s  ",
           connected & 1 ? "OK" : "--", connected & 2 ? "OK" : "--",
           connected & 4 ? "OK" : "--");
  textLine(36, line);
  snprintf(line, sizeof(line), "A:%d  B:%d  C:%d  Stick press:%d ",
           !!(pressed & 1), !!(pressed & 2), !!(pressed & 4), !!(pressed & 8));
  textLine(64, line);
  textLine(92, "Motion from neutral (mg)");
  snprintf(line, sizeof(line), "%6d / %6d / %6d   ", ax, ay, az);
  textLine(120, line);
  if (lastX >= 0) display.fillCircle(lastX, lastY, 6, TFT_BLACK);
  display.fillCircle(x, y, 6, pressed ? TFT_WHITE : TFT_CYAN);
  lastX = x;
  lastY = y;
  lastFrameAt = millis();
  waiting = false;
  return true;
}

int beginVideo() {
  if (videoSession) return 0;  // Only one stream may own the display.
  nextVideoSession = nextVideoSession == 2147483647 ? 1 : nextVideoSession + 1;
  videoSession = nextVideoSession;
  display.fillScreen(TFT_BLACK);
  textLine(10, "RetroArch / TFT bridge");
  textLine(294, "C + stick press: menu");
  lastX = -1;
  lastFrameAt = millis();
  waiting = false;
  return videoSession;
}

String pollVideo(int session) {
  if (!videoSession || session != videoSession) return String("");
  String inputs = readInputs();
  lastFrameAt = millis();
  return inputs;
}

String videoTile(int session, int tile, MsgPack::bin_t<uint8_t> data) {
  static uint16_t pixels[ArcadeVideo::TILE_PIXELS * 4];
  if (!videoSession || session != videoSession ||
      !ArcadeVideo::decode(tile, data.data(), data.size(), pixels)) return String("");
  display.drawRGBBitmap(80 + (tile % 10) * 32, 40 + (tile / 10) * 16, pixels, 32, 16);
  return pollVideo(session);  // Return fresh controls after each acknowledged tile.
}

bool endVideo(int session) {
  if (!videoSession || session != videoSession) return false;
  showWaiting();
  return true;
}

// ---- Game rendering: Python owns the rules, the sketch only draws. ----

const int TILE = 20;
const int COLS = 24;
const int ROWS = 16;
const int BAND_HEIGHT = 75;  // Four fog bands below the HUD row.
const uint16_t BAND_COLORS[4] = {0xCE79, 0xBDF7, 0xAD75, 0x9CF2};
const uint16_t INK = 0x1082;    // #111111 silhouettes
const uint16_t WOOD = 0x4963;   // dark brown barrier
const uint16_t STONE = 0x39C7;  // dark gray pillar
const uint16_t SHADE = 0x4A69;  // #4D4D49: background stalactites
const uint16_t RIM = 0x842F;    // #85857F: pale lip on walkable edges
// Element colours are the only colour in the game.
const uint16_t FIRE = 0xEBA5;        // #E8742A
const uint16_t FIRE_CORE = 0xF6A8;   // #F5D547
const uint16_t WATER = 0x3D5E;       // #3FA9F5
const uint16_t WATER_LIGHT = 0xAEFF; // #A8DCFF
const uint16_t EARTH = 0x6E8D;       // #6FD16F
const uint16_t EARTH_DARK = 0x3C69;  // #3E8E4A
const uint16_t AIR = 0x9F3E;         // #9FE7F5
const uint16_t AIR_DARK = 0x2D59;    // #2BA9C9
const uint16_t BOLT = 0xF6A8;        // #F5D547
const uint16_t ICE = 0xCFBF;         // #CFF6FF ice shards, bird essence
const uint16_t ICE_DARK = 0x4DBC;    // #4FB6E0
const uint16_t POOL_DEEP = 0x1B76;   // #1F6FB2 deep water
const uint16_t POOL_TOP = 0x7E9F;    // #7FD0FF water surface
const uint16_t FROZEN = 0xDF9F;      // #DDF3FF frozen water, whitish blue
const uint16_t FROZEN_SHADE = 0xAEDE;  // #A9D8F0
const uint16_t HILL_FAR = 0xA513;    // #A3A39D grassland: distant hills
const uint16_t HILL_NEAR = 0x8C70;   // #8C8C86 nearer hills
const uint16_t HILL_TREE = 0x738D;   // #73736E silhouette trees on the hills
// Indexed by colour id: 0 sword, 1 fire, 2 water, 3 earth, 4 air, 5 lightning, 6 ice.
const uint16_t ELEMENT_MAIN[7] = {INK, FIRE, WATER, EARTH, AIR_DARK, BOLT, ICE_DARK};
const uint16_t ELEMENT_LIGHT[7] = {INK, FIRE_CORE, WATER_LIGHT, EARTH_DARK, AIR, TFT_WHITE, ICE};
// A switch, not a table of string pointers: pointer tables in data need load-time
// relocation, which stopped the sketch from starting at all.
const char* elementName(int element) {
  switch (element) {
    case 1: return "FIRE";
    case 2: return "WATER";
    case 3: return "EARTH";
    case 4: return "AIR";
    case 5: return "LIGHTNING";
  }
  return "SWORD";
}
char tiles[ROWS][COLS];

const int MAX_SPRITES = 30;  // HUD, hearts, special, prompt, waterfall, hero, 9 enemies, 14 effects
const int SPRITE_BYTES = 6;  // type u8, x i16, y i16, flags u8 (little-endian)
const uint8_t SPRITE_PLAYER = 1;
const uint8_t SPRITE_FIREBALL = 2;  // centre; flags bit 0 facing right, bits 1-2 frame
const uint8_t SPRITE_WATER = 3;     // centre of the orb
const uint8_t SPRITE_BURST = 4;     // centre; flags bits 0-2 element, bits 3-5 frame
const uint8_t SPRITE_SPIKES = 5;    // bottom centre on the ground; flags = height step 0-4
const uint8_t SPRITE_GUST = 6;      // centre; flags bit 0 facing right, bits 1-2 frame
const uint8_t SPRITE_BOLT = 7;      // top centre; flags bits 2-7 length/4, bits 0-1 frame
const uint8_t SPRITE_HUD = 8;       // top-left of the HUD; flags = element
// Enemies: top-left of their box; flags bit 0 facing right, bit 1 walk/flap frame, bit 3 hit flash.
const uint8_t SPRITE_THORNLING = 9;  // 16x14, orange eyes
const uint8_t SPRITE_GOLEM = 10;     // 20x24, green eyes
const uint8_t SPRITE_WISP = 11;      // 16x12, white eyes
const uint8_t SPRITE_HEARTS = 12;    // top-left; flags = hearts left (of 3)
const uint8_t SPRITE_PROMPT = 13;    // top centre; flags = absorb progress 0-10
const uint8_t SPRITE_CRAB = 14;      // enemy crab, 14x8 box; bit 0 right, bit 1 step, bit 3 hit flash
const uint8_t SPRITE_CORPSE = 15;    // dead animal; bit 0 right, bits 1-2 glow frame, bit 3 fox (else crab)
const uint8_t SPRITE_PLAYER_CRAB = 16;  // hero as a crab; bit 0 right, bit 1 step, bit 2 spitting, bit 3 dancing
const uint8_t SPRITE_SHARD = 17;     // ice shard centre; bit 0 right
const uint8_t SPRITE_WATERFALL = 18; // top-left, 40 px wide; bits 0-1 frame, bit 2 frozen, bits 3-7 height in tiles
const uint8_t SPRITE_FLAME = 19;     // bottom centre of a burning tile; bits 0-1 frame, bit 2 big
const uint8_t SPRITE_FOX = 20;       // enemy fox, 16x12 box; bit 0 right, bit 1 step, bit 2 airborne, bit 3 flash
const uint8_t SPRITE_SPECIAL = 22;   // top bar: lightning charge; bits 0-1 kills (3 = ready), bit 2 blink, bit 3 dim (animal form)
const uint8_t SPRITE_DRAGON = 23;    // boss, 150x120 top-left; bit 0 ice armour, 1 wing, 2 flash, 3 breath, 4-7 hp
const uint8_t SPRITE_MAMMOTH = 24;   // enemy mammoth, 36x34; bit 0 right, 1 step, 2 air, 3 flash
const uint8_t SPRITE_PLAYER_MAMMOTH = 25;  // hero as a mammoth, 30x30; bit 3 trumpeting
const uint8_t SPRITE_PLAYER_FOX = 21;  // hero as a fox; bit 0 right, bit 1 step, bit 2 airborne, bit 3 shooting, bit 4 howling
// Type 0 keeps a slot but draws nothing (blinking hero, dead enemies).
Sprite shown[MAX_SPRITES];
int shownCount = 0;

// Changed regions are composed off-screen and sent in one transfer, so no flicker.
const int CANVAS_PIXELS = 12000;
uint16_t canvasPixels[CANVAS_PIXELS];

class RegionCanvas : public Adafruit_GFX {
 public:
  RegionCanvas(int16_t w, int16_t h) : Adafruit_GFX(w, h) {}
  void drawPixel(int16_t x, int16_t y, uint16_t color) override {
    if (x >= 0 && y >= 0 && x < _width && y < _height) canvasPixels[y * _width + x] = color;
  }
  void fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) override {
    int x0 = max((int)x, 0), y0 = max((int)y, 0);
    int x1 = min(x + w, (int)_width), y1 = min(y + h, (int)_height);
    for (int row = y0; row < y1; ++row) {
      for (int col = x0; col < x1; ++col) canvasPixels[row * _width + col] = color;
    }
  }
};

bool isSolid(char t) { return t == '#' || t == 'W' || t == 'P' || t == 'I' || t == 'T' || t == 'K'; }

// Row 0 is the HUD; its first char marks a grassland stage.
bool grassTheme() { return tiles[0][0] == 'G'; }

char tileAt(int c, int r) {
  return (c < 0 || c >= COLS || r < 0 || r >= ROWS) ? '.' : tiles[r][c];
}

uint8_t tileHash(int c, int r, int k) {
  return (uint8_t)(((uint32_t)(c * 73 + r * 151 + k * 197) * 2654435761u) >> 24);
}

// Slope tiles: local surface height above the tile bottom (floor) or rock depth
// below the tile top (ceiling) at the left and right edges. Matches main.py.
bool floorShape(char t, int& left, int& right) {
  switch (t) {
    case '/': left = 0; right = 20; return true;
    case '\\': left = 20; right = 0; return true;
    case 'a': left = 0; right = 10; return true;
    case 'A': left = 10; right = 20; return true;
    case 'e': left = 20; right = 10; return true;
    case 'E': left = 10; right = 0; return true;
    case 'h': left = 10; right = 10; return true;
  }
  return false;
}

bool ceilShape(char t, int& left, int& right) {
  switch (t) {
    case 'b': left = 20; right = 0; return true;
    case 'd': left = 0; right = 20; return true;
    case 'i': left = 20; right = 10; return true;
    case 'j': left = 10; right = 0; return true;
    case 'k': left = 0; right = 10; return true;
    case 'l': left = 10; right = 20; return true;
    case 'm': left = 10; right = 10; return true;
    case 'n': left = 10; right = 10; return true;  // low overhang: crab-only crawlspace
  }
  return false;
}

bool isRock(char t) {
  int l, r;
  return isSolid(t) || t == '~' || t == 'I' || floorShape(t, l, r) || ceilShape(t, l, r);
}

uint16_t bandAt(int screenY) {
  return screenY < TILE ? BAND_COLORS[0] : BAND_COLORS[min(3, (screenY - TILE) / BAND_HEIGHT)];
}

// Every tile draws only inside its own 20x20 cell, so partial redraws stay seamless.
// Black is anything you can stand on or touch; gray is background.
void drawTile(Adafruit_GFX& g, int c, int r, int ox, int oy) {
  char t = tiles[r][c];
  int x = c * TILE - ox, y = r * TILE - oy;
  int left, right;
  if (grassTheme() && !isRock(t) && t != 'Y' && tileAt(c, r + 1) == '#') {
    // Grass tufts grow up from the ground into this (empty) cell, so feet stand in the grass.
    for (int i = 0; i < TILE; i += 2) {
      int h = 2 + (tileHash(c, r, i) % 5);
      g.drawFastVLine(x + i, y + TILE - h, h, INK);
    }
  }
  if (t == '#') {
    g.fillRect(x, y, TILE, TILE, INK);
    for (int k = 0; k < 2; ++k) {  // Speckled rock.
      uint8_t h = tileHash(c, r, k);
      g.fillRect(x + 4 + h % 12, y + 5 + (h >> 4) % 10, 2, 1, STONE);
    }
    // Round every exposed corner so the rock reads as worn cave stone.
    bool round[2][2] = {};
    for (int sy = 0; sy < 2; ++sy) {
      for (int sx = 0; sx < 2; ++sx) {
        int dx = sx ? 1 : -1, dy = sy ? 1 : -1;
        if ((r <= 1 && dy < 0) || isRock(tileAt(c + dx, r)) || isRock(tileAt(c, r + dy)) ||
            isRock(tileAt(c + dx, r + dy))) continue;
        round[sy][sx] = true;
        int cx = x + (sx ? 12 : 0), cy = y + (sy ? 12 : 0);
        g.fillRect(cx, cy, 8, 8, bandAt(r * TILE + (sy ? 16 : 4)));
        g.fillCircle(x + (sx ? 11 : 8), y + (sy ? 11 : 8), 8, INK);
      }
    }
    if (!grassTheme() && r > 1 && !isRock(tileAt(c, r - 1)) && tileAt(c, r - 1) != '=') {  // Walkable lip, flush with the feet.
      int x0 = round[0][0] ? 6 : 0, x1 = round[0][1] ? 14 : TILE;
      g.drawFastHLine(x + x0, y, x1 - x0, RIM);
    }
  } else if (floorShape(t, left, right)) {  // Sloped floor with a lip (cave) or tufts (grass) along the surface.
    g.fillTriangle(x, y + TILE - left, x + TILE - 1, y + TILE - right, x + TILE - 1, y + TILE - 1, INK);
    g.fillTriangle(x, y + TILE - left, x + TILE - 1, y + TILE - 1, x, y + TILE - 1, INK);
    if (grassTheme()) {
      for (int i = 0; i < TILE; i += 3) {
        int sy = y + TILE - left - (right - left) * i / TILE;
        g.drawFastVLine(x + i, sy - 3 - tileHash(c, r, i) % 3, 4, INK);
      }
    } else {
      g.drawLine(x, y + TILE - left, x + TILE - 1, y + TILE - right, RIM);
    }
  } else if (ceilShape(t, left, right)) {  // Sloped rock overhang.
    g.fillTriangle(x, y, x + TILE - 1, y, x + TILE - 1, y + right, INK);
    g.fillTriangle(x, y, x + TILE - 1, y + right, x, y + left, INK);
  } else if (t == '=') {  // Thin one-way stone ledge with a jagged underside.
    g.fillRect(x, y, TILE, 7, INK);
    g.drawFastHLine(x, y, TILE, RIM);
    uint8_t h = tileHash(c, r, 0);
    g.fillTriangle(x + 2, y + 7, x + 9, y + 7, x + 4 + h % 3, y + 11 + h % 4, INK);
    g.fillTriangle(x + 10, y + 7, x + 18, y + 7, x + 13 + (h >> 3) % 3, y + 10 + (h >> 5) % 5, INK);
  } else if (t == '~') {  // Deep blue pool; the top row gets a bright surface with ripples.
    g.fillRect(x, y, TILE, TILE, POOL_DEEP);
    if (tileAt(c, r - 1) != '~') {
      g.fillRect(x, y, TILE, 3, POOL_TOP);
      uint8_t h = tileHash(c, r, 2);
      g.drawFastHLine(x + h % 10, y + 6, 6, POOL_TOP);
      g.drawFastHLine(x + (h >> 4) % 12, y + 11, 4, WATER);
    } else {
      g.drawFastHLine(x + tileHash(c, r, 3) % 14, y + 9, 5, WATER);
    }
  } else if (t == 'I') {  // The frozen pool: whitish-blue ice with cracks.
    g.fillRect(x, y, TILE, TILE, FROZEN);
    if (tileAt(c, r - 1) != 'I') g.drawFastHLine(x, y, TILE, TFT_WHITE);
    uint8_t h = tileHash(c, r, 4);
    g.drawLine(x + h % 8, y + 3 + (h >> 3) % 6, x + 8 + h % 10, y + 12 + (h >> 5) % 6, FROZEN_SHADE);
    g.drawLine(x + 8 + h % 10, y + 12 + (h >> 5) % 6, x + 19, y + 9 + h % 7, FROZEN_SHADE);
  } else if (t == 'v') {  // Stalactites hanging from the rock above.
    uint8_t h = tileHash(c, r, 1);
    g.fillTriangle(x + 4, y, x + 15, y, x + 9 + h % 3, y + 12 + h % 7, SHADE);
    g.fillTriangle(x + 15, y, x + 19, y, x + 17, y + 5 + (h >> 4) % 4, SHADE);
  } else if (t == 'W') {  // Bramble: a tangle of thorny black vines (burns).
    uint8_t h = tileHash(c, r, 5);
    for (int k = 0; k < 4; ++k) {
      int y0 = y + (k * 5 + h % 5) % TILE, y1 = y + (k * 7 + (h >> 3) % 7 + 9) % TILE;
      g.drawLine(x, y0, x + TILE - 1, y1, INK);
      g.drawLine(x, y0 + 1, x + TILE - 1, y1 + 1, INK);
      int tx = x + 3 + (k * 5 + h) % 14, ty = y0 + (y1 - y0) * (tx - x) / TILE;
      g.fillTriangle(tx - 2, ty, tx + 2, ty, tx, ty - 4, INK);
    }
    g.drawLine(x + h % 20, y, x + (h >> 2) % 20, y + TILE - 1, INK);
    g.drawLine(x + 1 + h % 20, y, x + 1 + (h >> 2) % 20, y + TILE - 1, INK);
  } else if (t == 'K') {  // Boulder with cracks; stacked ones read as a pile. Only the mammoth breaks them.
    uint8_t h = tileHash(c, r, 9);
    if (tileAt(c, r - 1) == 'K') g.fillRect(x + 3, y, 14, 8, INK);
    if (tileAt(c, r + 1) == 'K' || isRock(tileAt(c, r + 1))) g.fillRect(x + 3, y + 12, 14, 8, INK);
    g.fillCircle(x + 10, y + 10, 9, INK);
    g.drawLine(x + 4 + h % 4, y + 6, x + 10, y + 11, RIM);
    g.drawLine(x + 10, y + 11, x + 15, y + 6 + (h >> 4) % 6, RIM);
    g.drawLine(x + 10, y + 11, x + 8 + (h >> 2) % 5, y + 17, STONE);
  } else if (t == 'T') {  // Giant tree trunk: black with bark grain (burns).
    g.fillRect(x, y, TILE, TILE, INK);
    uint8_t h = tileHash(c, r, 6);
    g.drawFastVLine(x + 4 + h % 4, y + (h >> 2) % 6, 9, STONE);
    g.drawFastVLine(x + 13 + (h >> 4) % 4, y + 6 + (h >> 5) % 6, 8, STONE);
  } else if (t == 'Y') {  // Canopy: clumps of black leaves (burns).
    for (int k = 0; k < 6; ++k) {
      uint8_t h = tileHash(c, r, k + 7);
      g.fillCircle(x + 3 + h % 14, y + 3 + (h >> 4) % 14, 3 + (h >> 3) % 3, INK);
    }
    if (tileAt(c, r + 1) == 'Y' || tileAt(c, r + 1) == 'T') g.fillRect(x + 2, y + 10, 16, 10, INK);
    if (tileAt(c - 1, r) == 'Y') g.fillRect(x, y + 5, 10, 10, INK);
    if (tileAt(c + 1, r) == 'Y') g.fillRect(x + 10, y + 5, 10, 10, INK);
  } else if (t == 'P') {
    g.fillRect(x + 2, y, TILE - 4, TILE, STONE);
  } else if (t == '^') {
    for (int i = 0; i < TILE; i += 5) g.fillTriangle(x + i, y + TILE, x + i + 4, y + TILE, x + i + 2, y + TILE - 9, INK);
  }
}

int hillFar(int x) { return 135 + (int)(20.0f * sinf(x * 0.012f) + 9.0f * sinf(x * 0.035f + 1.3f)); }
int hillNear(int x) { return 190 + (int)(16.0f * sinf(x * 0.02f + 2.1f) + 7.0f * sinf(x * 0.05f + 0.4f)); }

// Two layers of rolling hills with silhouette trees, all in grays behind the play.
void drawHills(Adafruit_GFX& g, int ox, int oy, int w, int h) {
  for (int i = 0; i < w; ++i) {
    int top = max(hillFar(ox + i), oy);
    if (top < oy + h) g.drawFastVLine(i, top - oy, oy + h - top, HILL_FAR);
    top = max(hillNear(ox + i), oy);
    if (top < oy + h) g.drawFastVLine(i, top - oy, oy + h - top, HILL_NEAR);
  }
  static const int16_t TREES[6] = {30, 115, 205, 290, 365, 450};
  for (int k = 0; k < 6; ++k) {
    int tx = TREES[k], base = hillNear(tx) + 2;
    if (tx + 14 < ox || tx - 14 > ox + w) continue;
    g.fillRect(tx - 1 - ox, base - 16 - oy, 3, 16, HILL_TREE);
    g.fillCircle(tx - ox, base - 22 - oy, 8, HILL_TREE);
    g.fillCircle(tx - 6 - ox, base - 17 - oy, 5, HILL_TREE);
    g.fillCircle(tx + 6 - ox, base - 18 - oy, 5, HILL_TREE);
  }
}

void drawBackground(Adafruit_GFX& g, int ox, int oy, int w, int h) {
  for (int b = -1; b < 4; ++b) {  // b = -1 is the HUD row, drawn in the lightest band.
    int top = b < 0 ? 0 : TILE + b * BAND_HEIGHT;
    int bottom = b < 0 ? TILE : top + BAND_HEIGHT;
    int y0 = max(top, oy), y1 = min(bottom, oy + h);
    if (y0 < y1) g.fillRect(0, y0 - oy, w, y1 - y0, BAND_COLORS[max(b, 0)]);
  }
  if (grassTheme()) drawHills(g, ox, oy, w, h);
  for (int r = oy / TILE; r <= min((oy + h - 1) / TILE, ROWS - 1); ++r) {
    for (int c = ox / TILE; c <= min((ox + w - 1) / TILE, COLS - 1); ++c) drawTile(g, c, r, ox, oy);
  }
}

// Player: 12x22 box at (x, y); flags bit 0 = facing right, bits 1+ = pose.
// Poses: 0 idle, 1-2 walk, 3 air, 4 wind-up, 5 slash, 6 follow-through,
// 7 low wind-up, 8 rising cut, 9 thrust, 10 thrust recovery, 11 air down-slash, 12 air recovery.
// The sword is all black; thin black arcs show the swing.
void drawPlayer(Adafruit_GFX& g, int x, int y, uint8_t flags) {
  bool right = flags & 1;
  int pose = flags >> 1;
  auto mx = [&](int dx) { return right ? x + dx : x + 11 - dx; };
  auto rect = [&](int dx, int dy, int w, int h) {
    g.fillRect(right ? x + dx : x + 12 - dx - w, y + dy, w, h, INK);
  };
  auto line = [&](int dx0, int dy0, int dx1, int dy1) {
    g.drawLine(mx(dx0), y + dy0, mx(dx1), y + dy1, INK);
  };
  auto blade = [&](int dx0, int dy0, int dx1, int dy1) {  // two pixels thick
    line(dx0, dy0, dx1, dy1);
    line(dx0, dy0 + 1, dx1, dy1 + 1);
  };

  g.fillCircle(mx(6), y + 5, 5, INK);
  g.fillRoundRect(x + 2, y + 9, 8, 10, 2, INK);
  if (pose == 1) { rect(1, 18, 2, 4); rect(9, 18, 2, 4); }
  else if (pose == 2) { rect(4, 18, 2, 4); rect(6, 18, 2, 4); }
  else if (pose == 3 || pose >= 11) { rect(2, 17, 2, 3); rect(8, 16, 2, 3); }
  else if (pose == 9) { rect(0, 18, 2, 4); rect(10, 18, 2, 4); }  // lunge stance
  else { rect(3, 18, 2, 4); rect(7, 18, 2, 4); }
  g.fillRect(right ? x + 7 : x + 3, y + 3, 2, 2, TFT_WHITE);
  g.fillRect(right ? x + 10 : x + 1, y + 3, 1, 2, TFT_WHITE);

  blade(7, 17, -6, 21);  // Scabbard on the hip, trailing behind the legs.

  switch (pose) {
    case 4:  // Raised behind the head.
      blade(9, 11, 3, -6);
      rect(7, 11, 5, 2);
      break;
    case 5:  // Straight out, pointed tip, arc from above.
      rect(11, 11, 18, 3);
      line(29, 11, 32, 12);
      line(29, 13, 32, 12);
      rect(10, 9, 2, 7);
      line(6, -8, 18, -4); line(18, -4, 27, 3); line(27, 3, 31, 9);
      break;
    case 6:  // Follow-through, blade low.
      blade(10, 14, 24, 22);
      line(8, 12, 12, 16);
      break;
    case 7:  // Low, blade trailing behind for the rising cut.
      blade(9, 15, -5, 22);
      rect(8, 13, 2, 5);
      break;
    case 8:  // Rising cut, arc sweeping up from the ground.
      blade(10, 12, 24, -4);
      rect(9, 11, 4, 2);
      line(14, 22, 24, 15); line(24, 15, 29, 3); line(29, 3, 26, -8);
      break;
    case 9:  // Lunging thrust with speed lines behind.
      rect(11, 12, 21, 2);
      line(32, 12, 33, 13);
      rect(10, 10, 2, 6);
      rect(-7, 8, 5, 1); rect(-9, 13, 6, 1); rect(-6, 18, 4, 1);
      break;
    case 10:  // Thrust recovery.
      blade(10, 13, 26, 17);
      rect(9, 11, 2, 5);
      break;
    case 11:  // Airborne down-slash, arc curling under the feet.
      blade(9, 14, 17, 24);
      rect(8, 12, 4, 2);
      line(21, -2, 27, 8); line(27, 8, 25, 18); line(25, 18, 18, 25);
      break;
    case 12:  // Air recovery, blade pointing down.
      blade(9, 15, 12, 24);
      break;
    default:  // Sheathed: hilt and crossguard angle forward-up from the hip.
      blade(9, 16, 14, 13);
      rect(10, 13, 2, 6);  // Just outside the body (x+2..x+9) so it shows.
  }
  if (pose >= 13 && pose <= 17) {  // Casting: arm out, palm glowing in the element colour.
    int element = pose - 12;
    rect(9, 11, 7, 2);
    g.fillCircle(mx(17), y + 12, 3, ELEMENT_MAIN[element]);
    g.fillCircle(mx(17), y + 12, 1, ELEMENT_LIGHT[element]);
  }
}

void drawElementIcon(Adafruit_GFX& g, int x, int y, int element) {
  switch (element) {
    case 0: g.drawLine(x + 2, y + 11, x + 11, y + 2, INK); g.drawLine(x + 3, y + 11, x + 11, y + 3, INK);
            g.drawLine(x + 2, y + 7, x + 6, y + 11, INK); break;
    case 1: g.fillCircle(x + 6, y + 8, 4, FIRE); g.fillTriangle(x + 2, y + 8, x + 10, y + 8, x + 6, y, FIRE);
            g.fillCircle(x + 6, y + 9, 2, FIRE_CORE); break;
    case 2: g.fillCircle(x + 6, y + 8, 4, WATER); g.fillTriangle(x + 2, y + 7, x + 10, y + 7, x + 6, y, WATER);
            g.fillCircle(x + 5, y + 8, 1, WATER_LIGHT); break;
    case 3: g.fillTriangle(x + 6, y, x + 1, y + 11, x + 11, y + 11, EARTH);
            g.drawLine(x + 6, y, x + 6, y + 11, EARTH_DARK); break;
    case 4: for (int i = 0; i < 3; ++i) g.drawFastHLine(x + i * 2, y + 3 + i * 3, 10 - i * 2, AIR_DARK);
            g.drawCircle(x + 10, y + 5, 2, AIR_DARK); break;
    case 5: g.fillTriangle(x + 7, y, x + 2, y + 7, x + 6, y + 7, BOLT); g.fillTriangle(x + 6, y + 5, x + 10, y + 5, x + 4, y + 12, BOLT);
            g.drawLine(x + 7, y, x + 2, y + 7, INK); g.drawLine(x + 10, y + 5, x + 4, y + 12, INK); break;
  }
}

// Jagged bolt; the frame picks the zig-zag so it crackles.
void drawBolt(Adafruit_GFX& g, int x, int y, int length, int frame) {
  static const int8_t OFFS[7] = {0, 5, -4, 6, -6, 3, -2};
  int px = x, py = y;
  for (int i = 1; py < y + length; ++i) {
    int ny = min(y + length, py + 12), nx = x + (ny == y + length ? 0 : OFFS[(i + frame * 3) % 7]);
    g.drawLine(px - 1, py, nx - 1, ny, BOLT);
    g.drawLine(px + 1, py, nx + 1, ny, BOLT);
    g.drawLine(px, py, nx, ny, TFT_WHITE);
    px = nx; py = ny;
  }
  g.fillCircle(x, y + length, 4, BOLT);
  g.fillCircle(x, y + length, 2, TFT_WHITE);
}

// Crab on a 14x8 box: shell, two claws, three legs a side, eyes on stalks.
void drawCrab(Adafruit_GFX& g, int x, int y, int step, uint16_t body, uint16_t eye, uint16_t claw) {
  g.fillRoundRect(x + 2, y + 2, 10, 5, 2, body);
  g.fillCircle(x, y + 2, 2, body);
  g.fillCircle(x + 13, y + 2, 2, body);
  g.drawPixel(x - 1, y, claw);
  g.drawPixel(x + 14, y, claw);
  for (int i = 0; i < 3; ++i) {
    int lx = x + 3 + i * 2, rx = x + 10 - i * 2, kick = (step + i) % 2;
    g.drawLine(lx, y + 6, lx - 2 + kick, y + 8, body);
    g.drawLine(rx, y + 6, rx + 2 - kick, y + 8, body);
  }
  g.drawFastVLine(x + 5, y - 1, 3, body);
  g.drawFastVLine(x + 8, y - 1, 3, body);
  g.fillRect(x + 5, y - 2, 1, 2, eye);
  g.fillRect(x + 8, y - 2, 1, 2, eye);
}

// Fox on a 16x12 box: bushy tail with a glowing tip, pointed ears, running legs.
void drawFox(Adafruit_GFX& g, int x, int y, bool right, int step, bool air, uint16_t body, uint16_t eye,
             uint16_t tip, bool howl) {
  auto m = [&](int dx) { return right ? x + dx : x + 15 - dx; };
  g.fillTriangle(m(3), y + 5, m(-6), y + 1, m(-3), y + 9, body);  // tail
  g.fillCircle(m(-5), y + 3, 2, tip);
  g.fillRoundRect(x + 2, y + 4, 12, 6, 3, body);
  if (howl) {  // head thrown back, snout to the sky, ears laid back
    g.fillTriangle(m(10), y + 6, m(14), y + 6, m(12), y - 1, body);  // neck
    g.fillCircle(m(12), y, 3, body);
    g.fillTriangle(m(11), y - 2, m(14), y - 1, m(14), y - 8, body);  // snout up
    g.fillTriangle(m(10), y - 1, m(7), y - 4, m(11), y + 1, body);   // ear
    g.drawPixel(m(13), y - 1, eye);
  } else {
    g.fillCircle(m(12), y + 4, 3, body);
    g.fillTriangle(m(13), y + 3, m(18), y + 6, m(13), y + 7, body);  // snout
    g.fillTriangle(m(10), y + 2, m(11), y - 3, m(13), y + 2, body);  // ears
    g.fillTriangle(m(12), y + 2, m(14), y - 2, m(14), y + 3, body);
  }
  if (air) {  // legs tucked
    g.fillRect(x + 4, y + 9, 8, 2, body);
  } else {
    int a = step ? 1 : 0;
    g.fillRect(m(4 + a) - (right ? 0 : 1), y + 9, 2, 3, body);
    g.fillRect(m(6 - a) - (right ? 0 : 1), y + 9, 2, 3, body);
    g.fillRect(m(10 + a) - (right ? 0 : 1), y + 9, 2, 3, body);
    g.fillRect(m(12 - a) - (right ? 0 : 1), y + 9, 2, 3, body);
  }
  if (!howl) g.drawPixel(m(13), y + 3, eye);
}

// Mammoth on a w x h box: shaggy body with a hump, hair fringe, domed head, trunk
// (raised when it trumpets), curling white tusks and pillar legs.
void drawMammoth(Adafruit_GFX& g, int x, int y, int w, int h, bool right, int step, bool air, bool trumpet,
                 uint16_t body, uint16_t eye) {
  auto m = [&](int dx) { return right ? x + dx : x + w - 1 - dx; };
  g.fillRoundRect(x + 1, y + 6, w - 6, h - 14, 8, body);
  g.fillCircle(m(w / 3), y + 9, w / 4, body);                        // hump
  for (int i = 0; i + 6 < w - 4; i += 5)                              // hair fringe
    g.fillTriangle(x + 2 + i, y + h - 9, x + 7 + i, y + h - 9, x + 4 + i, y + h - 4, body);
  g.fillCircle(m(w - 7), y + 10, 8, body);                            // domed head
  if (trumpet) {
    g.fillTriangle(m(w - 3), y + 9, m(w + 7), y - 4, m(w + 1), y + 12, body);
  } else {
    g.fillRect(m(w - 1) - (right ? 1 : 3), y + 12, 4, h - 16, body);  // trunk hanging down
    g.fillCircle(m(w + 1), y + h - 4, 2, body);
  }
  g.drawLine(m(w - 4), y + 16, m(w + 5), y + 21, TFT_WHITE);         // tusk, curling up
  g.drawLine(m(w - 4), y + 17, m(w + 5), y + 22, TFT_WHITE);
  g.drawLine(m(w + 5), y + 21, m(w + 8), y + 14, TFT_WHITE);
  int a = air ? 0 : step;
  g.fillRect(m(4 + a) - (right ? 0 : 5), y + h - 10, 6, 10 - (air ? 4 : 0), body);
  g.fillRect(m(12 - a) - (right ? 0 : 5), y + h - 10, 6, 10 - (air ? 4 : 0), body);
  g.fillRect(m(w - 14 + a) - (right ? 0 : 5), y + h - 10, 6, 10 - (air ? 4 : 0), body);
  g.fillRect(m(w - 8 - a) - (right ? 0 : 5), y + h - 10, 6, 10 - (air ? 4 : 0), body);
  g.fillRect(m(w - 6) - (right ? 0 : 1), y + 7, 2, 2, eye);
}

// Dragon facing left on a 150x120 box: spiked back, horned head with teeth, burning
// eye, beating wings, clawed feet, curling tail. Eye, chest and wing edges glow with
// the phase (orange fire aura / ice-blue armour).
void drawDragon(Adafruit_GFX& g, int x, int y, uint8_t f) {
  bool iceArmour = f & 1, wingUp = f & 2, flash = f & 4, breath = f & 8;
  int hp = f >> 4;
  uint16_t body = flash ? RIM : INK, glow = iceArmour ? ICE : FIRE, glowDark = iceArmour ? ICE_DARK : FIRE_CORE;
  auto X = [&](int v) { return x + v * 3 / 2; };  // drawn on a 100x80 grid, scaled up 1.5x
  auto Y = [&](int v) { return y + v * 3 / 2; };
  g.drawRect(x + 30, y - 9, 92, 6, INK);          // health bar
  g.fillRect(x + 31, y - 8, hp * 6, 4, glowDark);
  if (wingUp) g.fillTriangle(X(40), Y(34), X(92), Y(-2), X(76), Y(36), SHADE);   // far wing
  else g.fillTriangle(X(40), Y(36), X(96), Y(30), X(74), Y(50), SHADE);
  g.fillTriangle(X(70), Y(52), X(99), Y(40), X(82), Y(66), body);               // tail
  g.fillTriangle(X(96), Y(42), X(99), Y(26), X(90), Y(38), body);
  g.fillRoundRect(X(30), Y(36), 84, 45, 16, body);                              // body
  for (int i = 0; i < 5; ++i)                                                   // back spikes
    g.fillTriangle(X(36 + i * 9), Y(37), X(42 + i * 9), Y(37), X(38 + i * 9), Y(28 - (i % 2) * 3), body);
  g.fillRect(X(36), Y(60), 15, 30, body);                                       // legs
  g.fillRect(X(66), Y(60), 15, 30, body);
  for (int i = 0; i < 3; ++i) {                                                 // claws
    g.fillTriangle(X(33) + i * 6, Y(80), X(33) + i * 6 + 5, Y(80), X(33) + i * 6 - 2, Y(80) - 6, body);
    g.fillTriangle(X(63) + i * 6, Y(80), X(63) + i * 6 + 5, Y(80), X(63) + i * 6 - 2, Y(80) - 6, body);
  }
  g.fillCircle(X(40), Y(50), 10, glow);                                         // glowing chest
  g.fillCircle(X(40), Y(50), 5, glowDark);
  g.fillTriangle(X(30), Y(40), X(46), Y(38), X(18), Y(18), body);               // neck
  g.fillTriangle(X(30), Y(40), X(18), Y(18), X(12), Y(26), body);
  g.fillRoundRect(X(2), Y(14), 36, 18, 6, body);                                // head
  g.fillTriangle(X(16), Y(14), X(28), Y(-2), X(22), Y(15), body);               // horns
  g.fillTriangle(X(9), Y(14), X(13), Y(1), X(16), Y(15), body);
  if (breath) {  // jaw open: teeth and a glowing throat
    g.fillTriangle(X(2), Y(26), X(20), Y(25), X(6), Y(38), body);
    g.fillCircle(X(6), Y(27), 5, glow);
    for (int i = 0; i < 4; ++i) g.fillTriangle(x + 6 + i * 6, Y(26), x + 10 + i * 6, Y(26), x + 8 + i * 6, Y(26) + 5, TFT_WHITE);
  } else {
    g.fillRect(X(4), Y(25), 27, 6, body);
    for (int i = 0; i < 3; ++i) g.fillTriangle(x + 8 + i * 8, Y(25), x + 11 + i * 8, Y(25), x + 9 + i * 8, Y(25) + 4, TFT_WHITE);
  }
  g.fillRect(X(9), Y(17), 9, 5, glow);                                          // burning eye
  g.drawFastVLine(X(9) + 4, Y(17), 5, INK);
  if (wingUp) {                                                                 // near wing
    g.fillTriangle(X(36), Y(40), X(70), Y(-4), X(62), Y(40), body);
    g.drawLine(X(70), Y(-4), X(62), Y(40), glowDark);
  } else {
    g.fillTriangle(X(36), Y(40), X(84), Y(44), X(58), Y(62), body);
    g.drawLine(X(84), Y(44), X(58), Y(62), glowDark);
  }
}

// Flickering flame rising from the bottom centre (x, y).
void drawFlame(Adafruit_GFX& g, int x, int y, int frame, bool big) {
  int h = big ? 20 : 12, sway = (frame % 2) ? 2 : -2;
  g.fillTriangle(x - 8, y, x + 8, y, x + sway, y - h, FIRE);
  g.fillTriangle(x - 9, y, x - 1, y, x - 5 - sway, y - h * 2 / 3, FIRE);
  g.fillTriangle(x + 1, y, x + 9, y, x + 5 + sway, y - h * 3 / 4, FIRE);
  g.fillTriangle(x - 5, y, x + 5, y, x - sway / 2, y - h * 2 / 3, FIRE_CORE);
  g.fillTriangle(x - 2, y, x + 2, y, x, y - h / 3 - frame, TFT_WHITE);
}

// Black silhouettes; only the eyes carry colour. A hit flashes the body gray.
void drawEnemy(Adafruit_GFX& g, uint8_t type, int x, int y, uint8_t flags) {
  bool right = flags & 1;
  int frame = (flags >> 1) & 1;
  uint16_t body = (flags & 8) ? RIM : INK;
  if (type == SPRITE_THORNLING) {
    g.fillRoundRect(x + 1, y + 5, 14, 8, 4, body);
    g.fillTriangle(x + 2, y + 7, x + 5, y + 7, x + 3, y + 1, body);
    g.fillTriangle(x + 6, y + 6, x + 10, y + 6, x + 8, y, body);
    g.fillTriangle(x + 11, y + 7, x + 14, y + 7, x + 13, y + 2, body);
    g.fillRect(x + 3 + frame, y + 12, 2, 2, body);
    g.fillRect(x + 11 - frame, y + 12, 2, 2, body);
    g.fillRect(x + (right ? 9 : 3), y + 7, 2, 2, FIRE);
    g.fillRect(x + (right ? 12 : 6), y + 7, 2, 2, FIRE);
  } else if (type == SPRITE_GOLEM) {
    g.fillRoundRect(x + 1, y + 6, 18, 13, 3, body);
    g.fillRoundRect(x + 5, y, 10, 8, 2, body);
    g.fillRect(x - 1, y + 8 + frame, 3, 9, body);
    g.fillRect(x + 18, y + 9 - frame, 3, 9, body);
    g.fillRect(x + 4, y + 19, 4, 5 - frame, body);
    g.fillRect(x + 12, y + 19, 4, 4 + frame, body);
    g.fillRect(x + (right ? 10 : 6), y + 3, 2, 2, EARTH);
    g.fillRect(x + (right ? 13 : 9), y + 3, 2, 2, EARTH);
  } else {  // Wisp: flapping wings and a trailing tail.
    if (frame) {
      g.fillTriangle(x + 5, y + 6, x - 2, y - 1, x + 2, y + 8, body);
      g.fillTriangle(x + 11, y + 6, x + 18, y - 1, x + 14, y + 8, body);
    } else {
      g.fillTriangle(x + 5, y + 6, x - 3, y + 10, x + 2, y + 3, body);
      g.fillTriangle(x + 11, y + 6, x + 19, y + 10, x + 14, y + 3, body);
    }
    g.fillTriangle(x + 6, y + 9, x + 10, y + 9, x + (right ? 5 : 11), y + 15, body);
    g.fillCircle(x + 8, y + 6, 4, body);
    g.fillRect(x + (right ? 9 : 5), y + 5, 1, 2, TFT_WHITE);
    g.fillRect(x + (right ? 11 : 7), y + 5, 1, 2, TFT_WHITE);
  }
}

void setBox(int box[4], int x, int y, int w, int h) {
  box[0] = x; box[1] = y; box[2] = w; box[3] = h;
}

// Screen rectangle each sprite may touch; redraws cover exactly this area.
void spriteBox(const Sprite& s, int box[4]) {
  switch (s.type) {
    case SPRITE_PLAYER:
      if ((s.flags >> 1) <= 3) setBox(box, s.x - 8, s.y - 1, 28, 25);  // sheathed: body, hilt, scabbard
      else setBox(box, s.x - 22, s.y - 10, 56, 36);                      // sword or cast reach both sides
      break;
    case SPRITE_FIREBALL: setBox(box, s.x - 14, s.y - 8, 28, 16); break;
    case SPRITE_WATER: setBox(box, s.x - 7, s.y - 7, 14, 14); break;
    case SPRITE_BURST: setBox(box, s.x - 16, s.y - 16, 32, 32); break;
    case SPRITE_SPIKES: setBox(box, s.x - 12, s.y - 28, 24, 28); break;
    case SPRITE_GUST: setBox(box, s.x - 14, s.y - 12, 28, 24); break;
    case SPRITE_BOLT: setBox(box, s.x - 8, s.y, 16, (s.flags >> 2) * 4 + 5); break;
    case SPRITE_HUD: setBox(box, s.x, s.y, 320, 14); break;  // icon + the longest moves line
    case SPRITE_PROMPT: setBox(box, s.x - 56, s.y - 1, 112, 18); break;
    case SPRITE_CRAB: setBox(box, s.x - 3, s.y - 3, 20, 12); break;
    case SPRITE_PLAYER_CRAB: setBox(box, s.x - 4, s.y - 9, 22, 18); break;  // raised claws and sparkles when dancing
    case SPRITE_FOX: setBox(box, s.x - 7, s.y - 4, 30, 17); break;  // tail and snout
    case SPRITE_PLAYER_FOX: setBox(box, s.x - 7, s.y - 9, 30, 22); break;  // snout raised when howling
    case SPRITE_CORPSE: setBox(box, s.x - 10, s.y - 14, 56, 50); break;  // a mammoth body is big
    case SPRITE_FLAME: setBox(box, s.x - 11, s.y - 22, 22, 23); break;
    case SPRITE_WATERFALL: setBox(box, s.x, s.y, 40, (s.flags >> 3) * TILE + 6); break;
    case SPRITE_SHARD: setBox(box, s.x - 8, s.y - 4, 16, 8); break;
    case SPRITE_THORNLING: setBox(box, s.x - 2, s.y - 2, 20, 18); break;
    case SPRITE_GOLEM: setBox(box, s.x - 2, s.y - 2, 24, 28); break;
    case SPRITE_WISP: setBox(box, s.x - 6, s.y - 6, 28, 22); break;
    case SPRITE_HEARTS: setBox(box, s.x, s.y, 58, 14); break;
    case SPRITE_SPECIAL: setBox(box, s.x, s.y, 70, 14); break;
    case SPRITE_DRAGON: setBox(box, s.x, s.y - 10, 150, 130); break;
    case SPRITE_MAMMOTH: setBox(box, s.x - 10, s.y - 5, 56, 40); break;          // tusks and trunk
    case SPRITE_PLAYER_MAMMOTH: setBox(box, s.x - 10, s.y - 5, 50, 36); break;  // icon + "LIGHTNING  [C]"
    default: setBox(box, s.x, s.y, 0, 0);
  }
}

void drawSprite(Adafruit_GFX& g, const Sprite& s, int ox, int oy) {
  int x = s.x - ox, y = s.y - oy, f = s.flags;
  switch (s.type) {
    case SPRITE_PLAYER:
      drawPlayer(g, x, y, f);
      break;
    case SPRITE_FIREBALL: {  // Flickering core with a flame tail behind.
      int back = (f & 1) ? -1 : 1, flick = (f >> 1) & 3;
      g.fillTriangle(x + back * 13, y - 1 + flick % 2, x, y - 5, x, y + 5, FIRE);
      g.fillCircle(x, y, 5, FIRE);
      g.fillCircle(x - back, y, 3 - flick % 2, FIRE_CORE);
      break;
    }
    case SPRITE_WATER:
      g.fillCircle(x, y, 5, WATER);
      g.fillCircle(x - 2, y - 2, 2, WATER_LIGHT);
      break;
    case SPRITE_BURST: {  // Droplets/sparks flying outward.
      int element = f & 7, step = (f >> 3) & 7, reach = 4 + step * 2;
      for (int i = 0; i < 8; ++i) {
        static const int8_t DX[8] = {10, 7, 0, -7, -10, -7, 0, 7}, DY[8] = {0, -7, -10, -7, 0, 7, 10, 7};
        int px = x + DX[i] * reach / 10, py = y + DY[i] * reach / 10;
        g.fillCircle(px, py, step < 3 ? 2 : 1, i % 2 ? ELEMENT_LIGHT[element] : ELEMENT_MAIN[element]);
      }
      break;
    }
    case SPRITE_SPIKES: {  // Crystal spikes erupting from the ground.
      int h = min(f, 4) * 6;
      if (h == 0) break;
      g.fillTriangle(x - 10, y, x - 2, y, x - 6, y - h * 2 / 3, EARTH_DARK);
      g.fillTriangle(x + 2, y, x + 10, y, x + 6, y - h * 3 / 4, EARTH_DARK);
      g.fillTriangle(x - 5, y, x + 5, y, x, y - h, EARTH);
      g.drawLine(x, y - h, x, y - 1, EARTH_DARK);
      break;
    }
    case SPRITE_GUST: {  // Curling crescents of wind.
      int dir = (f & 1) ? 1 : -1, phase = (f >> 1) & 3;
      for (int i = 0; i < 3; ++i) {
        int cx = x - dir * i * 6, cy = y + (i - 1) * 7 + (phase + i) % 2;
        g.drawCircleHelper(cx, cy, 6 - i, dir > 0 ? 6 : 9, AIR_DARK);
        g.drawCircleHelper(cx - dir, cy, 5 - i, dir > 0 ? 6 : 9, AIR);
      }
      break;
    }
    case SPRITE_BOLT:
      drawBolt(g, x, y, (f >> 2) * 4, f & 3);
      break;
    case SPRITE_HUD:  // Top bar: current form's icon and its moves.
      if (f == 2 || f == 4) drawCrab(g, x + 2, y + 5, 0, INK, TFT_WHITE, ICE);
      else if (f == 3 || f == 5) drawFox(g, x + 6, y + 3, true, 0, false, INK, TFT_WHITE, FIRE, false);
      else if (f == 6 || f == 7) {  // little mammoth: dome, trunk, tusk
        g.fillCircle(x + 8, y + 6, 6, INK);
        g.fillRect(x + 13, y + 6, 3, 8, INK);
        g.drawLine(x + 11, y + 10, x + 17, y + 12, TFT_WHITE);
        g.drawPixel(x + 11, y + 4, TFT_WHITE);
      } else if (f == 8) {          // dragon head
        g.fillRoundRect(x + 2, y + 4, 14, 6, 2, INK);
        g.fillTriangle(x + 10, y + 4, x + 15, y - 1, x + 13, y + 5, INK);
        g.fillRect(x + 5, y + 5, 2, 2, FIRE);
      }
      else { g.fillCircle(x + 6, y + 3, 3, INK); g.fillRoundRect(x + 3, y + 6, 7, 7, 2, INK); }
      g.setTextSize(1);
      g.setTextColor(INK);
      g.setCursor(x + 26, y + 4);
      switch (f) {
        case 1: g.print("A JUMP   B SLASH   C SHIFT"); break;
        case 2: g.print("STICK CRAWL  A DANCE  B ICE SPIT  C SHIFT"); break;
        case 3: g.print("A JUMP x2  UP+A HOWL  B FIRE  C SHIFT"); break;
        case 4: g.print("ABSORB A CRAB TO MOVE ON"); break;
        case 5: g.print("ABSORB A FOX TO MOVE ON"); break;
        case 6: g.print("CHARGE BOULDERS  A JUMP  B TRUMPET  C SHIFT"); break;
        case 7: g.print("ABSORB A MAMMOTH TO MOVE ON"); break;
        case 8: g.print("DRAGON: FIRE MELTS ICE, ICE QUENCHES FIRE"); break;
        default: g.print("A JUMP   B SLASH");
      }
      break;
    case SPRITE_SPECIAL: {  // Lightning icon and three charge pips; "SHAKE!" flashes when full.
      int charge = f & 3;
      bool dim = f & 8;  // lightning is the hero's alone
      drawElementIcon(g, x, y + 1, 5);
      if (charge >= 3 && (f & 4) && !dim) {
        g.setTextSize(1);
        g.setTextColor(INK);
        g.setCursor(x + 16, y + 4);
        g.print("SHAKE!");
      } else {
        for (int i = 0; i < 3; ++i) {
          g.fillRect(x + 16 + i * 10, y + 3, 8, 8, i < charge ? (dim ? SHADE : BOLT) : RIM);
          g.drawRect(x + 16 + i * 10, y + 3, 8, 8, INK);
        }
      }
      break;
    }
    case SPRITE_PROMPT:
      g.setTextSize(1);
      g.setTextColor(INK);
      g.setCursor(x - 54, y);
      g.print("HOLD STICK: ABSORB");
      g.drawRect(x - 30, y + 10, 60, 5, INK);
      if (f) g.fillRect(x - 29, y + 11, min((int)f, 10) * 58 / 10, 3, ICE_DARK);
      break;
    case SPRITE_CRAB:
      drawCrab(g, x, y, (f >> 1) & 1, (f & 8) ? RIM : INK, ICE_DARK, ICE_DARK);
      break;
    case SPRITE_PLAYER_CRAB:
      if (f & 8) {  // Dancing: bob, wave one claw high then the other, sparkles above.
        int up = (f >> 1) & 1, bob = up ? -1 : 0;
        drawCrab(g, x, y + bob, up, INK, TFT_WHITE, ICE);
        g.fillCircle(up ? x : x + 13, y - 4 + bob, 2, INK);
        g.drawLine(up ? x + 2 : x + 11, y + 2 + bob, up ? x : x + 13, y - 3 + bob, INK);
        g.drawPixel(up ? x - 1 : x + 14, y - 6 + bob, ICE);
        g.drawPixel(x + 4 + up * 6, y - 8, ICE);
        g.drawPixel(x + 9 - up * 6, y - 6, ICE_DARK);
      } else {
        drawCrab(g, x, y, (f >> 1) & 1, INK, TFT_WHITE, ICE);
      }
      if (f & 4) g.fillCircle(x + ((f & 1) ? 16 : -3), y + 3, 2, ICE);  // spit puff
      break;
    case SPRITE_FOX:
      drawFox(g, x, y, f & 1, (f >> 1) & 1, f & 4, (f & 8) ? RIM : INK, FIRE_CORE, FIRE, false);
      break;
    case SPRITE_PLAYER_FOX:
      drawFox(g, x, y, f & 1, (f >> 1) & 1, f & 4, INK, TFT_WHITE, (f & 8) ? FIRE_CORE : FIRE, f & 16);
      break;
    case SPRITE_MAMMOTH:
      drawMammoth(g, x, y, 36, 34, f & 1, (f >> 1) & 1, f & 4, false, (f & 8) ? RIM : INK, EARTH);
      break;
    case SPRITE_PLAYER_MAMMOTH:
      drawMammoth(g, x, y, 30, 30, f & 1, (f >> 1) & 1, f & 4, f & 8, INK, TFT_WHITE);
      break;
    case SPRITE_DRAGON:
      drawDragon(g, x, y, f);
      break;
    case SPRITE_FLAME:
      drawFlame(g, x, y, f & 3, f & 4);
      break;
    case SPRITE_CORPSE: {  // Dead animal on its back; its essence drifts up (ice for crabs, embers for foxes).
      bool right = f & 1, fox = f & 8, dino = f & 16;
      int frame = (f >> 1) & 3;
      uint16_t a = dino ? EARTH_DARK : fox ? FIRE : ICE_DARK, b = dino ? EARTH : fox ? FIRE_CORE : ICE;
      if (dino) {  // a fallen mammoth on its side
        auto m = [&](int dx) { return right ? x + dx : x + 35 - dx; };
        g.fillRoundRect(x, y + 18, 34, 16, 7, INK);
        g.fillCircle(m(30), y + 24, 7, INK);
        g.drawLine(m(30), y + 30, m(40), y + 33, TFT_WHITE);
        for (int i = 0; i < 4; ++i) g.fillRect(m(5 + i * 7), y + 10, 5, 9, INK);
      } else if (fox) {
        auto m = [&](int dx) { return right ? x + dx : x + 15 - dx; };
        g.fillTriangle(m(2), y + 8, m(-6), y + 6, m(-4), y + 11, INK);
        g.fillRoundRect(x + 1, y + 6, 13, 5, 2, INK);
        g.fillCircle(m(13), y + 8, 3, INK);
        g.drawLine(m(5), y + 6, m(4), y + 2, INK);
        g.drawLine(m(10), y + 6, m(11), y + 2, INK);
      } else {
        g.fillRoundRect(x + 2, y + 4, 10, 4, 2, INK);
        for (int i = 0; i < 3; ++i) g.drawLine(x + 3 + i * 3, y + 4, x + 2 + i * 3, y + 1, INK);
        g.fillCircle(x, y + 5, 2, INK);
        g.fillCircle(x + 13, y + 5, 2, INK);
      }
      for (int i = 0; i < 4; ++i) {
        int rise = ((frame + i) % 4) * 3;
        g.fillCircle(x + i * 5, y - 2 - rise, 1 + (frame + i) % 2, i % 2 ? b : a);
      }
      break;
    }
    case SPRITE_WATERFALL: {
      int h = (f >> 3) * TILE, frame = f & 3;
      if (f & 4) {  // Frozen: whitish-blue ice with soft vertical shading and icicles.
        g.fillRect(x, y, 40, h, FROZEN);
        for (int i = 0; i < 5; ++i) g.drawFastVLine(x + 4 + i * 8 + (i % 2) * 2, y, h, FROZEN_SHADE);
        g.drawFastVLine(x + 1, y, h, TFT_WHITE);
        g.drawFastVLine(x + 22, y, h, TFT_WHITE);
        for (int i = 0; i < 4; ++i) g.fillTriangle(x + i * 10, y + h, x + i * 10 + 9, y + h, x + i * 10 + 4, y + h + 5, FROZEN);
      } else {      // Flowing: bright blue with streaks sliding down and foam at the bottom.
        g.fillRect(x, y, 40, h, WATER);
        for (int i = 0; i < 6; ++i) {
          int sx = x + 3 + i * 6 + (i % 2);
          for (int sy = ((frame * 6 + i * 9) % 24) - 24; sy < h; sy += 24) {
            int top = max(sy, 0), len = min(sy + 12, h) - top;
            if (len > 0) g.drawFastVLine(sx, y + top, len, WATER_LIGHT);
          }
        }
        g.drawFastVLine(x, y, h, POOL_TOP);
        g.drawFastVLine(x + 39, y, h, POOL_DEEP);
        for (int i = 0; i < 5; ++i) g.fillCircle(x + 4 + i * 8, y + h - 1 + ((frame + i) % 2), 3 - (frame + i) % 2, TFT_WHITE);
      }
      break;
    }    case SPRITE_SHARD: {
      int dir = (f & 1) ? 1 : -1;
      g.fillTriangle(x + dir * 7, y, x - dir * 4, y - 2, x - dir * 4, y + 2, ICE);
      g.drawLine(x + dir * 7, y, x - dir * 4, y - 2, ICE_DARK);
      g.drawLine(x + dir * 7, y, x - dir * 4, y + 2, ICE_DARK);
      g.drawPixel(x - dir * 7, y, ICE_DARK);
      break;
    }
    case SPRITE_THORNLING:
    case SPRITE_GOLEM:
    case SPRITE_WISP:
      drawEnemy(g, s.type, x, y, f);
      break;
    case SPRITE_HEARTS:
      for (int i = 0; i < 3; ++i) {  // Black when full, pale when lost.
        int hx = x + 4 + i * 18;
        uint16_t color = i < f ? INK : RIM;
        g.fillCircle(hx + 3, y + 5, 3, color);
        g.fillCircle(hx + 9, y + 5, 3, color);
        g.fillTriangle(hx, y + 6, hx + 12, y + 6, hx + 6, y + 12, color);
      }
      break;
  }
}

bool overlaps(const int a[4], const int b[4]) {
  return a[0] < b[0] + b[2] && b[0] < a[0] + a[2] && a[1] < b[1] + b[3] && b[1] < a[1] + a[3];
}

// Redraw background, tiles and every overlapping sprite inside one screen rectangle.
void renderRegion(int x, int y, int w, int h) {
  int x1 = min(x + w, 480), y1 = min(y + h, 320);
  x = max(x, 0);
  y = max(y, 0);
  w = x1 - x;
  if (w <= 0 || y1 <= y) return;
  int stripRows = max(1, CANVAS_PIXELS / w);
  for (int top = y; top < y1; top += stripRows) {
    int rows = min(stripRows, y1 - top);
    RegionCanvas canvas(w, rows);
    drawBackground(canvas, x, top, w, rows);
    int strip[4] = {x, top, w, rows};
    for (int i = 0; i < shownCount; ++i) {
      int box[4];
      spriteBox(shown[i], box);
      if (overlaps(box, strip)) drawSprite(canvas, shown[i], x, top);
    }
    display.drawRGBBitmap(x, top, canvasPixels, w, rows);
  }
}

bool gameRoomRow(int row, MsgPack::bin_t<uint8_t> data) {
  if (row < 0 || row >= ROWS || data.size() != COLS) return false;
  for (int c = 0; c < COLS; ++c) tiles[row][c] = (char)data[c];
  roomReady = false;
  return true;
}

// One tile changed (burnt away, frozen...): redraw it and its neighbours' rounded edges.
bool gameSetTile(int col, int row, int ch) {
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return false;
  tiles[row][col] = (char)ch;
  if (roomReady && !videoSession) renderRegion(col * TILE - TILE, row * TILE - TILE, TILE * 3, TILE * 3);
  return true;
}

bool gameRoomDraw() {
  if (videoSession) return false;
  shownCount = 0;
  renderRegion(0, 0, 480, 320);
  roomReady = true;
  lastFrameAt = millis();
  waiting = false;
  return true;
}

// Draws the frame and returns fresh controls (same JSON as arcade_read_inputs), so
// each game loop needs only one round trip. Returns "" when the room must be
// (re)sent, e.g. after the display timeout or while RetroArch owns the display.
String gameFrame(MsgPack::bin_t<uint8_t> data) {
  if (videoSession || !roomReady) return String("");
  static Sprite next[MAX_SPRITES];
  static int dirty[MAX_SPRITES * 2][4];
  int count = min((int)data.size() / SPRITE_BYTES, MAX_SPRITES);
  for (int i = 0; i < count; ++i) {
    const uint8_t* p = data.data() + i * SPRITE_BYTES;
    next[i] = {p[0], (int16_t)(p[1] | (p[2] << 8)), (int16_t)(p[3] | (p[4] << 8)), p[5]};
  }

  int dirtyCount = 0;
  for (int i = 0; i < max(count, shownCount); ++i) {
    bool had = i < shownCount, has = i < count;
    if (had && has && shown[i].type == next[i].type && shown[i].x == next[i].x &&
        shown[i].y == next[i].y && shown[i].flags == next[i].flags) continue;
    int a[4], b[4];
    if (had) spriteBox(shown[i], a);
    if (has) spriteBox(next[i], b);
    if (had && has) {
      int ux = min(a[0], b[0]), uy = min(a[1], b[1]);
      int uw = max(a[0] + a[2], b[0] + b[2]) - ux, uh = max(a[1] + a[3], b[1] + b[3]) - uy;
      if (uw * uh <= 2 * (a[2] * a[3] + b[2] * b[3])) {
        int* d = dirty[dirtyCount++];
        d[0] = ux; d[1] = uy; d[2] = uw; d[3] = uh;
        continue;
      }
    }
    if (had) memcpy(dirty[dirtyCount++], a, sizeof(a));
    if (has) memcpy(dirty[dirtyCount++], b, sizeof(b));
  }

  memcpy(shown, next, sizeof(Sprite) * count);
  shownCount = count;
  for (int i = 0; i < dirtyCount; ++i) renderRegion(dirty[i][0], dirty[i][1], dirty[i][2], dirty[i][3]);
  lastFrameAt = millis();
  waiting = false;
  return readInputs();
}

void setup() {
  Modulino.begin(Wire1);
  Wire1.setClock(400000);  // Fast-mode I2C: the three Modulinos are read every frame.
  buttons.begin();
  movementReady = movement.begin();
  display.begin();
  display.setRotation(1);  // Landscape: 480 x 320.
  display.fillScreen(TFT_BLACK);
  display.setTextSize(2);
  display.setTextWrap(false);
  textLine(10, "UNO Q arcade starter");
  display.drawRect(12, 160, 456, 148, TFT_WHITE);
  showWaiting();
  if (Bridge.begin()) {
    Bridge.provide_safe("arcade_read_inputs", readInputs);
    Bridge.provide_safe("arcade_draw_frame", drawFrame);
    Bridge.provide_safe("arcade_video_begin", beginVideo);
    Bridge.provide_safe("arcade_video_tile", videoTile);
    Bridge.provide_safe("arcade_video_poll", pollVideo);
    Bridge.provide_safe("arcade_video_end", endVideo);
    Bridge.provide_safe("game_room_row", gameRoomRow);
    Bridge.provide_safe("game_room_draw", gameRoomDraw);
    Bridge.provide_safe("game_frame", gameFrame);
    Bridge.provide_safe("game_set_tile", gameSetTile);
  } else {
    textLine(36, "Bridge failed: restart app");
  }
}

void loop() {
  if (!waiting && millis() - lastFrameAt > 1500) showWaiting();
  delay(5);
}
