#pragma once

#include <stdint.h>

// Kept in a header so Arduino's generated prototypes can see it.
struct Sprite {
  uint8_t type;
  int16_t x, y;
  uint8_t flags;
};
