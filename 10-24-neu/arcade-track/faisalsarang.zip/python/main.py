import json
import math
import struct
import time

from arduino.app_utils import App, Bridge
from preview import controls

START_STAGE = 1           # 1-8: stage to begin at (testing); earlier stages' forms are granted

# ---- Movement ----
STICK_DEADZONE = 45       # stick drift below this is ignored (stops idle jitter)
STICK_FULL = 100          # stick value that counts as full speed
GRAVITY = 950             # px/s^2
JUMP_CUT = 0.45           # vy multiplier when A is released mid-rise
MAX_FALL = 480            # px/s
COYOTE_TIME = 0.08        # s after leaving a ledge when a jump still counts
JUMP_BUFFER = 0.10        # s before landing when an A press still counts
WALK_FRAME_TIME = 0.12    # s per walk pose
STEP_UP = 8               # px climbed without jumping (slope tops, small lips)
SLOPE_SNAP = 8            # px the feet stick to the ground when walking downhill
MAX_DT = 0.05

# ---- Forms: the hero plus every animal absorbed so far (C cycles through them) ----
# Size, run speed, jump velocity (None = can't jump) and extra jumps in the air.
FORMS = {
    "human": {"w": 12, "h": 22, "speed": 115, "jump": -370, "air_jumps": 0},
    "crab": {"w": 14, "h": 8, "speed": 70, "jump": None, "air_jumps": 0},     # fits 1-tile crawlspaces
    "fox": {"w": 16, "h": 12, "speed": 145, "jump": -360, "air_jumps": 1},    # double jump
    "mammoth": {"w": 30, "h": 30, "speed": 75, "jump": -280, "air_jumps": 0},  # huge; charges through boulders
    "storm": {"w": 12, "h": 22, "speed": 150, "jump": -380, "air_jumps": 1},   # the Storm Walker
}
FORM_ORDER = ("human", "crab", "fox", "mammoth")
DOUBLE_JUMP_VELOCITY = -360  # fox reaches ~130 px with both jumps; cliffs are 100
SHARD_SPEED, SHARD_RANGE, SHARD_COOLDOWN = 330, 150, 0.3          # crab: short-range ice spit
FIREBALL_SPEED, FIREBALL_RANGE, FIREBALL_COOLDOWN = 260, 320, 0.35  # fox
ABSORB_TIME = 0.7         # s holding the stick click over a body
DANCE_TIME = 0.9          # crab: A dances (just for show)
HOWL_TIME = 0.7           # fox: stick up + A howls fire (just for show; plain A still jumps)
CORPSE_GRAVITY = 600

# ---- Sword (human form): each swing is (seconds, pose) steps; B again chains the next ----
COMBO = (
    ((0.05, 4), (0.10, 5), (0.10, 6)),    # 1: horizontal slash
    ((0.05, 7), (0.10, 8), (0.10, 6)),    # 2: rising cut
    ((0.07, 4), (0.12, 9), (0.16, 10)),   # 3: lunging thrust
)
AIR_SLASH = ((0.04, 4), (0.12, 11), (0.08, 12))  # downward slash while airborne
COMBO_WINDOW = 0.30       # s after a swing when B still continues the combo
COMBO_ACCEPT = 0.25       # fraction of a swing after which B queues the next one
ATTACK_MOVE = 0.4         # walking speed multiplier while swinging
LUNGE_SPEED = 190         # px/s forward during the thrust
LUNGE_POSE = 9
# Sword hitboxes per pose, relative to the hero facing right: (dx, dy, w, h).
SWORD_HITBOX = {5: (11, -8, 24, 28), 8: (6, -12, 24, 30), 9: (11, 0, 24, 18), 11: (2, -4, 26, 30)}

# ---- Enemies: black silhouettes; each leaves a body you can absorb ----
ENEMY_STATS = {
    "crab": {"w": 14, "h": 8, "hp": 1, "speed": 30, "hop": None, "weak": 1},   # hordes: one hit each
    "fox": {"w": 16, "h": 12, "hp": 2, "speed": 65, "hop": -260, "weak": 6},
    "mammoth": {"w": 36, "h": 34, "hp": 5, "speed": 30, "hop": None, "weak": 0},
}
ESSENCE_COLOR = {"crab": 6, "fox": 1, "mammoth": 3}  # ice, fire, earth green
FOX_HOP_EVERY = 1.6       # s between a fox's hops
SWORD_DAMAGE, WEAK_DAMAGE, OTHER_DAMAGE = 1, 3, 1
HIT_FLASH = 0.15          # s an enemy flashes pale after a hit
ENEMY_KNOCKBACK = 120     # px/s, decays quickly
HEARTS = 3
HURT_KNOCKBACK = (160, -220)  # px/s away from the enemy, and up
INVULNERABLE_TIME = 1.0   # s of blinking after taking a hit

# ---- Fire: brambles (W), tree trunk (T) and canopy (Y) burn; fire spreads tile to tile ----
BURNABLE = "WTY"
BURN_SPREAD = {"W": 0.15, "T": 0.40, "Y": 0.30}  # s before fire reaches a neighbour (the tree burns slowly)
FLAME_TIME = 0.9
WATERFALL_PULL = 260      # px/s the current drags you down
MAX_EFFECTS = 14

# ---- Lightning special: every kill charges it; shake the console to strike every enemy ----
SPECIAL_KILLS = 3         # kills to fill the bar
SHAKE_THRESHOLD_MG = 300  # a mild jolt: change in acceleration between frames (works at any holding angle)
SHAKE_JOLTS = 2           # jolts needed in a burst; one bump or a tilt is never enough
SHAKE_WINDOW = 1.2        # s the jolts must fall within
SPECIAL_POSE_TIME = 0.4   # s the hero holds the strike pose
BOLT_TIME = 0.45          # s each bolt stays on screen

TILE = 20
COLS, ROWS = 24, 16
SOLID = "#WPITK"           # rock, bramble, pillar, ice, trunk, cracked rock
CRACKED = "K"             # boulders: only the mammoth breaks them
ONE_WAY = "="
WATER_TILE = "~"
# Slope tiles: (left, right) surface height in px above the tile bottom.
FLOOR_SHAPES = {"/": (0, 20), "\\": (20, 0), "a": (0, 10), "A": (10, 20),
                "e": (20, 10), "E": (10, 0), "h": (10, 10)}
# Ceiling tiles: (left, right) rock depth in px below the tile top.
CEIL_SHAPES = {"b": (20, 0), "d": (0, 20), "i": (20, 10), "j": (10, 0),
               "k": (0, 10), "l": (10, 20), "m": (10, 10), "n": (10, 10)}
LOW_OVERHANG, OVERHANG_DEPTH = "n", 10  # 10 px slot underneath: crab (8 px) only
BUTTON_A, BUTTON_B, BUTTON_C, BUTTON_STICK = 1, 2, 4, 8

# Sprite types (must match the sketch).
SPRITE_NONE, SPRITE_PLAYER, SPRITE_FIREBALL, SPRITE_BURST, SPRITE_HUD = 0, 1, 2, 4, 8
SPRITE_HEARTS, SPRITE_PROMPT, SPRITE_CRAB, SPRITE_CORPSE, SPRITE_PLAYER_CRAB = 12, 13, 14, 15, 16
SPRITE_SHARD, SPRITE_WATERFALL, SPRITE_FLAME, SPRITE_FOX, SPRITE_PLAYER_FOX = 17, 18, 19, 20, 21
SPRITE_BOLT, SPRITE_SPECIAL = 7, 22
SPRITE_DRAGON, SPRITE_MAMMOTH, SPRITE_PLAYER_MAMMOTH = 23, 24, 25
SPRITE_BANNER, SPRITE_CAGE = 26, 27
STORM_FLAG = 128          # player sprite flag: the Storm Walker's crackling aura
FIRE, WATER, EARTH, LIGHTNING, ICE = 1, 2, 3, 5, 6  # colour ids for bursts (0 = black puff)

# ---- Dragon boss: alternates fire aura (only ice hurts) and ice armour (only fire hurts) ----
DRAGON_W, DRAGON_H = 150, 120
DRAGON_HP = 15             # hits of the right element (fits the 4-bit HP bar)
DRAGON_PHASE_TIME = 5.0   # s per phase
DRAGON_BREATH_EVERY = 2.0 # s between breaths, aimed at the hero
DRAGON_BREATH_SPEED = 170
DRAGON_DEATH_TIME = 1.6   # s of collapsing bursts
# Top-bar modes.
HUD_HUMAN, HUD_HUMAN_CAN_SHIFT, HUD_CRAB, HUD_FOX, HUD_NEED_CRAB, HUD_NEED_FOX = 0, 1, 2, 3, 4, 5
HUD_MAMMOTH, HUD_NEED_MAMMOTH, HUD_BOSS, HUD_STORM, HUD_PRISONER = 6, 7, 8, 9, 10

# Row 0 is the HUD (its first char "G" marks a grassland stage for the sketch);
# rows 1-15 are the playfield. # = rock, slope letters are in FLOOR_SHAPES /
# CEIL_SHAPES, v = stalactite, ~ = water, I = ice, W = bramble, T = tree trunk,
# Y = canopy, S = spawn, X = exit (the right screen edge is open on X rows).

# Stage 1, cave: crabs. Climb right, up the right shaft, left, up the left shaft,
# then right to the exit (shut until a crab is absorbed).
ROOM_1 = [
    r"........................",
    r"########################",
    r"#....v...kl#ij.vkl#ij..X",
    r"#......................X",
    r"#....aA#eE....ahE......X",
    r"#...####################",
    r"##......v....kl#ij...v.#",
    r"#.....................##",
    r"#..#...................#",
    r"#..#aA#eE..ahA#ehE.....#",
    r"###################....#",
    r"#kl#ij.........vkm##...#",
    r"##.....................#",
    r"#..............aE....###",
    r"#.S.ahA#eE..aA###eE....#",
    r"########################",
]

# Stage 2, cave: each tier is cut by a wall with a crawlspace at floor level
# that only the crab fits through. No enemies.
ROOM_2 = [
    r"........................",
    r"########################",
    r"#l#ij..v....v#kmlij....#",
    r"#............#........##",
    r"#S...ahA#eE............#",
    r"###################...##",
    r"#...ij...#...v...km....#",
    r"#........#.............#",
    r"#........#............##",
    r"#.............aA#eE....#",
    r"#...####################",
    r"#...mj.v....#.......v..X",
    r"#...........#..........X",
    r"#...........#..aA#eE...X",
    r"#....aAeE....aA#####eE.X",
    r"########################",
]

# Stage 3, the pool: hop the stepping stones as the human, spit ice at the
# waterfall from the last one as the crab (short range), then walk the ice.
ROOM_3 = [
    r"........................",
    r"###################..###",
    r"#...v....kl#ij.........#",
    r"#......................#",
    r"#......v...............#",
    r"#......................#",
    r"#......................#",
    r"#................v.....#",
    r"#......................#",
    r"#......................X",
    r"#............##........X",
    r"#.S.....##...##........X",
    r"#####...##...##......###",
    r"#####~~~##~~~##~~~~~~###",
    r"#####~~~##~~~##~~~~~~###",
    r"########################",
]

# Stage 4, grasslands: foxes. Absorb one to move on.
ROOM_4 = [
    r"G.......................",
    r".......................X",
    r".......................X",
    r".......................X",
    r".......................X",
    r".......................X",
    r".......................X",
    r".......................X",
    r".......................X",
    r".......................X",
    r".......................X",
    r".......................X",
    r".......................X",
    r".SahA#ehE...ahA#ehE....X",
    r"########################",
    r"########################",
]

# Stage 5: hedges to burn, cliffs that need the fox's double jump, and an exit
# that's a crab-only crawlspace under the overhang on the last cliff.
ROOM_5 = [
    r"G.......................",
    r"...................#####",
    r"............W......#####",
    r".....W......W......#####",
    r".....W......W......#####",
    r".....W......W......#####",
    r".....W......W......#####",
    r".....W......W......#####",
    r".....W......W......nnnnX",
    r".....W...#####....######",
    r".....W...#####....######",
    r".....W...#####.WW.######",
    r".....W...#####.WW.######",
    r".S...W...#####.WW.######",
    r"########################",
    r"########################",
]

# Stage 6: the giant tree. Burn the thicket, double-jump onto the rock and set the
# trunk alight above the stone wall that shields its base; then crawl out as the
# crab under the boulder.
ROOM_6 = [
    r"G.......................",
    r".............YYYYYYYY...",
    r"............YYYYYYYYYY..",
    r"............YYYTTTYYYY..",
    r".............YYTTTYYY...",
    r"...............TTT......",
    r"...WWW.........TTT......",
    r"...WWW.........TTT......",
    r"...WWW.........TTT......",
    r"...WWW..##...##TTT......",
    r"...WWW..##...##TTT..####",
    r"...WWW..##...##TTT..####",
    r"...WWW..##...##TTT..####",
    r".S.WWW..##...##TTTT.nnnX",
    r"########################",
    r"########################",
]

# Stage 7: the dragon's lair. Hide behind the low rock from its breath; climb the
# steps to the high ledge to shoot over it. The exit is behind the dragon.
ROOM_7 = [
    r"........................",
    r"########################",
    r"#...v.......v..........#",
    r"#......................#",
    r"#......................#",
    r"#......................#",
    r"#......................#",
    r"#......................#",
    r"#......................#",
    r"#....####..............#",
    r"#......................#",
    r"#.##...................X",
    r"#........##............X",
    r"#.S......##............X",
    r"########################",
    r"########################",
]

# Stage 8, the canyon: a mammoth to absorb, a hedge for the fox, and boulder piles
# too tall to jump that only the mammoth can charge through.
ROOM_8 = [
    r"G.......................",
    r".......................X",
    r".......................X",
    r".......................X",
    r".....W.................X",
    r".....W.................X",
    r".....W.................X",
    r".....W.........K...K...X",
    r".....W.........K...K...X",
    r".....W.........K...K...X",
    r".....W.........K...K...X",
    r".....W.........K...K...X",
    r".....W.........K...K...X",
    r".S...W.........K...K...X",
    r"########################",
    r"########################",
]

# Stage 9, the gauntlet: every form. Burn the hedge and double-jump the cliff (fox),
# freeze the waterfall from the clifftop (crab), clear the crabs with lightning
# (human), charge the boulders (mammoth), crawl out under the overhang (crab).
ROOM_9 = [
    r"........................",
    r"#############..#########",
    r"#...W.......v..........#",
    r"#...W..................#",
    r"#...W..................#",
    r"#...W............K..####",
    r"#...W............K..####",
    r"#...W............K..####",
    r"#...W............K..####",
    r"#...W............K..####",
    r"#...W.###........K..####",
    r"#...W.###........K..nnnX",
    r"#...W.###......#########",
    r"#...W.###~~~~~~#########",
    r"#.S.W.###~~~~~~#########",
    r"########################",
]

# Stage 10, the prisoner: a caged figure guarded by a pack. Free them to end the game.
ROOM_10 = [
    r"G.......................",
    r"........................",
    r"........................",
    r"........................",
    r"........................",
    r"........................",
    r"........................",
    r"........................",
    r"........................",
    r"........................",
    r"........................",
    r"........................",
    r"........................",
    r".S......................",
    r"########################",
    r"########################",
]

ROOMS = [ROOM_1, ROOM_2, ROOM_3, ROOM_4, ROOM_5, ROOM_6, ROOM_7, ROOM_8, ROOM_9, ROOM_10]
# Enemies per room: (kind, col, row) with row = the open cell they stand in.
ROOM_ENEMIES = [
    [("crab", 13, 14), ("crab", 10, 9), ("crab", 16, 4)],
    [("crab", 5, 4), ("crab", 9, 4), ("crab", 16, 4),       # horde: every tier is crawling
     ("crab", 5, 9), ("crab", 12, 9), ("crab", 17, 9),
     ("crab", 7, 14), ("crab", 16, 14), ("crab", 20, 14)],
    [],
    [("fox", 8, 12), ("fox", 13, 13), ("fox", 19, 12)],
    [("fox", 3, 13), ("fox", 7, 13), ("fox", 14, 13), ("fox", 17, 13),   # horde of foxes
     ("fox", 10, 8), ("fox", 11, 8), ("fox", 13, 8)],
    [],
    [],
    [("mammoth", 11, 13)],
    [("crab", 15, 11), ("crab", 16, 11), ("crab", 18, 11), ("crab", 19, 11)],
    [("fox", 9, 13), ("crab", 12, 13), ("fox", 14, 13), ("crab", 16, 13)],
]
ROOM_NEEDS = ["crab", None, None, "fox", None, None, None, "mammoth", None, None]  # exit shut until absorbed
# Waterfall per room: (left col, top row, bottom row exclusive, width in cols) or None.
ROOM_WATERFALL = [None, None, (19, 1, 13, 2), None, None, None, None, None, (13, 1, 13, 2), None]
ROOM_BOSS = [None, None, None, None, None, None, (325, 160), None, None, None]  # dragon's top-left, or None
ROOM_RANGE = [1, 1, 1, 1, 1, 1, 2.5, 1, 1, 1]  # attack range multiplier (the boss arena: reach it from anywhere)
CAGE_ROOM, CAGE_X, CAGE_Y, CAGE_W, CAGE_H = 9, 400, 236, 40, 44  # the prisoner in stage 10
FREE_TIME = 1.0           # s holding the stick click at the cage

# ---- The Storm Walker: the freed prisoner, played after the ending ----
STORM_STRIKE_RANGE = 260  # px: chain lightning reaches every enemy this close
STORM_COOLDOWN = 0.5
DASH_DISTANCE = 130       # px; the dash phases through anything in the way
DASH_COOLDOWN = 0.45
EXIT_LOCKED = False


def tile_at(room, col, row):
    if row < 0 or row >= ROWS:
        return "."
    if col < 0 or col >= COLS:
        # Screen edges are walls, except an exit marked X on the edge column.
        return "." if col >= COLS and room[row][COLS - 1] == "X" and not EXIT_LOCKED else "#"
    return room[row][col]


def shape_y(room, x, row, shapes, floor):
    """Surface y of a slope tile at screen x, or None if that tile isn't one."""
    col = math.floor(x / TILE)
    ch = tile_at(room, col, row)
    if ch not in shapes:
        return None
    left, right = shapes[ch]
    h = left + (right - left) * (x - col * TILE) / TILE
    return (row + 1) * TILE - h if floor else row * TILE + h


def solid_at(room, x, y):
    """True if the point is inside rock, including the filled part of slope tiles."""
    if not (0 <= x < COLS * TILE and 0 <= y < ROWS * TILE):
        return True
    row = math.floor(y / TILE)
    if tile_at(room, math.floor(x / TILE), row) in SOLID:
        return True
    s = shape_y(room, x, row, FLOOR_SHAPES, True)
    if s is not None:
        return y >= s
    s = shape_y(room, x, row, CEIL_SHAPES, False)
    return s is not None and y <= s


def probe(room, x, y, step, limit):
    """First y (moving by step) where the point hits rock, or None within limit px."""
    for d in range(0, limit, abs(step)):
        if solid_at(room, x, y + math.copysign(d, step)):
            return y + math.copysign(d, step)
    return None


def box_free(room, x, y, w, h):
    """True if no rock (slopes included) touches the box; samples edges every <= 6 px."""
    xs = [x + w * i / max(1, math.ceil(w / 6)) for i in range(math.ceil(w / 6) + 1)]
    ys = [y + h * i / max(1, math.ceil(h / 6)) for i in range(math.ceil(h / 6) + 1)]
    xs[-1] -= 0.01
    ys[-1] -= 0.01
    return not any(solid_at(room, px, py) for px in xs for py in ys)


def overlap(a, b):
    return a[0] < b[0] + b[2] and b[0] < a[0] + a[2] and a[1] < b[1] + b[3] and b[1] < a[1] + a[3]


def in_water(room, box):
    """True once the box dips more than a few px below the pool surface."""
    x, y, w, h = box
    for r in range(math.floor(y / TILE), math.floor((y + h - 1) / TILE) + 1):
        for c in range(math.floor(x / TILE), math.floor((x + w - 1) / TILE) + 1):
            if tile_at(room, c, r) == WATER_TILE and y + h > r * TILE + 4:
                return True
    return False


class Effect:
    """Coloured attack effects: Python moves them, the sketch only draws them."""

    def __init__(self, kind, x, y, vx=0.0, life=1.0, right=True, color=0, length=0, vy=0.0, hostile=False):
        self.kind, self.x, self.y, self.vx, self.vy = kind, x, y, vx, vy
        self.life, self.right, self.color, self.t, self.length = life, right, color, 0.0, length
        self.hostile = hostile    # the dragon's breath: hurts the hero, not enemies

    def update(self, room, dt, spawned, ignited):
        self.t += dt
        if self.kind in ("fire", "ice"):
            self.x += self.vx * dt
            self.y += self.vy * dt
            if solid_at(room, self.x, self.y):
                col, row = math.floor(self.x / TILE), math.floor(self.y / TILE)
                if self.kind == "fire" and tile_at(room, col, row) in BURNABLE:
                    ignited.append((col, row))
                spawned.append(Effect("burst", self.x - math.copysign(4, self.vx), self.y - 3, life=0.3,
                                      color=FIRE if self.kind == "fire" else ICE))
                return False
        return self.t < self.life

    def sprite(self):
        frame = int(self.t / 0.05)
        if self.kind == "fire":
            kind, flags = SPRITE_FIREBALL, self.right | (frame % 4) << 1
        elif self.kind == "ice":
            kind, flags = SPRITE_SHARD, self.right
        elif self.kind == "bolt":  # jagged; the frame re-rolls the zig-zag so it crackles
            kind, flags = SPRITE_BOLT, (self.length // 4) << 2 | frame % 4
        elif self.kind == "flame":  # big at first, smaller as it dies down
            kind, flags = SPRITE_FLAME, (frame % 4) | (4 if self.t < self.life * 0.6 else 0)
        else:
            kind, flags = SPRITE_BURST, self.color | min(frame, 5) << 3
        return struct.pack("<BhhB", kind, round(self.x), round(self.y), flags)


class Waterfall:
    """Falls from the ceiling into the pool. Its current drags you into the water
    until an ice shard freezes it (and the pool) solid."""

    def __init__(self, col, top, bottom, width):
        self.x, self.y, self.w, self.h = col * TILE, top * TILE, width * TILE, (bottom - top) * TILE
        self.frozen = False
        self.t = 0.0

    def rect(self):
        return (self.x, self.y, self.w, self.h)

    def sprite(self):
        if getattr(self, "gone", False):
            return struct.pack("<BhhB", SPRITE_NONE, self.x, self.y, 0)
        frame = 0 if self.frozen else int(self.t / 0.12) % 4
        flags = frame | (4 if self.frozen else 0) | (self.h // TILE) << 3
        return struct.pack("<BhhB", SPRITE_WATERFALL, self.x, self.y, flags)


class Enemy:
    def __init__(self, kind, col, row, room):
        stats = ENEMY_STATS[kind]
        self.kind, self.w, self.h, self.hp = kind, stats["w"], stats["h"], stats["hp"]
        self.speed, self.hop, self.weak = stats["speed"], stats["hop"], stats["weak"]
        self.x = col * TILE + (TILE - self.w) / 2
        ground = probe(room, self.x + self.w / 2, row * TILE, 2, 80)
        self.y = (ground if ground is not None else (row + 1) * TILE) - self.h
        self.right = False
        self.vy = self.knock = self.flash = self.t = 0.0
        self.grounded = True
        self.alive = True
        self.corpse = False       # a dead animal's body, waiting to be absorbed

    def box(self):
        return (self.x, self.y, self.w, self.h)

    def absorb_box(self):
        return (self.x - 8, self.y - 14, self.w + 16, self.h + 18)

    def centre(self):
        return self.x + self.w / 2, self.y + self.h / 2

    def fall(self, room, dt, gravity):
        """Gravity onto the floor (slopes included). Returns True when standing."""
        self.vy = min(MAX_FALL, self.vy + gravity * dt)
        cx = self.x + self.w / 2
        if self.vy >= 0 and solid_at(room, cx, self.y + self.h + self.vy * dt + 1):
            ground = probe(room, cx, self.y + self.h - 10, 1, 40)
            if ground is not None:
                self.y = ground - self.h
            self.vy = 0.0
            return True
        self.y += self.vy * dt
        return False

    def update(self, room, dt):
        self.t += dt
        if not self.alive:
            if self.corpse:
                self.fall(room, dt, CORPSE_GRAVITY)
            return
        self.flash = max(0.0, self.flash - dt)
        step = (self.speed if self.right else -self.speed) * dt + self.knock * dt
        self.knock *= 0.02 ** dt
        front = self.x + (self.w + 1 if step > 0 else -1) + step
        feet = self.y + self.h
        blocked = solid_at(room, front, feet - 6)
        no_floor = self.grounded and probe(room, front, feet - 4, 1, 14) is None
        if blocked or no_floor:
            if abs(self.knock) < 5:
                self.right = not self.right
        else:
            self.x += step
        if self.hop and self.grounded and self.t % FOX_HOP_EVERY < dt:
            self.vy = self.hop
        self.grounded = self.fall(room, dt, GRAVITY)

    def hurt(self, damage, from_x):
        self.hp -= damage
        self.flash = HIT_FLASH
        self.knock = ENEMY_KNOCKBACK if self.centre()[0] > from_x else -ENEMY_KNOCKBACK
        if self.hp <= 0:
            self.alive = False
            self.corpse = True
            self.vy = 0.0
        return not self.alive

    def sprite(self):
        if not self.alive:
            if self.corpse:  # glowing body; frame animates the essence
                flags = (int(self.right) | (int(self.t / 0.12) % 4) << 1 | (8 if self.kind == "fox" else 0)
                         | (16 if self.kind == "mammoth" else 0))
                return struct.pack("<BhhB", SPRITE_CORPSE, round(self.x), round(self.y), flags)
            return struct.pack("<BhhB", SPRITE_NONE, round(self.x), round(self.y), 0)
        frame = int(self.t / 0.15) % 2
        flags = int(self.right) | frame << 1 | (4 if not self.grounded else 0) | (8 if self.flash else 0)
        kind = {"fox": SPRITE_FOX, "crab": SPRITE_CRAB, "mammoth": SPRITE_MAMMOTH}[self.kind]
        return struct.pack("<BhhB", kind, round(self.x), round(self.y), flags)


class Dragon:
    """Stage 7 boss. Immune to the sword and the lightning special; each phase only
    the opposite element hurts it."""

    def __init__(self, x, y):
        self.x, self.y = x, y
        self.hp = DRAGON_HP
        self.t = self.flash = self.breath = 0.0
        self.dying = None         # time since the final blow
        self.alive = True

    @property
    def ice_armour(self):  # True: blue armour, only fire hurts; False: fire aura, only ice hurts
        return int(self.t / DRAGON_PHASE_TIME) % 2 == 1

    def hitbox(self):
        return (self.x + 12, self.y + 12, DRAGON_W - 18, DRAGON_H - 12)

    def mouth(self):
        return (self.x + 8, self.y + 38)

    def update(self, dt, player, effects):
        if not self.alive:
            return
        self.t += dt
        self.flash = max(0.0, self.flash - dt)
        self.breath = max(0.0, self.breath - dt)
        if self.dying is not None:  # bursts all over, then gone
            self.dying += dt
            if int(self.dying / 0.12) != int((self.dying - dt) / 0.12):
                k = int(self.dying / 0.12)
                effects.append(Effect("burst", self.x + 15 + (k * 37) % 70, self.y + 10 + (k * 23) % 60,
                                      life=0.3, color=(FIRE, ICE, 0)[k % 3]))
            if self.dying >= DRAGON_DEATH_TIME:
                self.alive = False
                print("The dragon falls.")
            return
        if int(self.t / DRAGON_BREATH_EVERY) != int((self.t - dt) / DRAGON_BREATH_EVERY):
            mx, my = self.mouth()
            px, py = player.x + player.w / 2, player.y + player.h / 2
            dist = max(1.0, math.hypot(px - mx, py - my))
            kind = "ice" if self.ice_armour else "fire"
            effects.append(Effect(kind, mx, my, vx=(px - mx) / dist * DRAGON_BREATH_SPEED,
                                  vy=(py - my) / dist * DRAGON_BREATH_SPEED, life=3.0, right=False, hostile=True))
            self.breath = 0.35

    def struck(self, kind):
        """A fireball or ice shard reached it. Returns the burst colour to show."""
        weak = "fire" if self.ice_armour else "ice"
        if self.dying is not None or kind != weak:
            return 0  # clink: a black puff, no damage
        self.hp -= 1
        self.flash = HIT_FLASH
        if self.hp <= 0:
            self.dying = 0.0
        return FIRE if kind == "fire" else ICE

    def sprite(self):
        if not self.alive:
            return struct.pack("<BhhB", SPRITE_NONE, self.x, self.y, 0)
        wing = int(self.t / 0.4) % 2
        flags = (int(self.ice_armour) | wing << 1 | (4 if self.flash or self.dying is not None else 0)
                 | (8 if self.breath else 0) | max(0, self.hp) << 4)
        return struct.pack("<BhhB", SPRITE_DRAGON, self.x, self.y, flags)


def resolve_combat(player, enemies, effects):
    """Sword and projectile hits on enemies, then enemy contact on the hero."""
    def damage(enemy, amount, from_x):
        if enemy.hurt(amount, from_x):  # died: a burst in its essence colour; charges the special
            cx, cy = enemy.centre()
            effects.append(Effect("burst", cx, cy, life=0.3, color=ESSENCE_COLOR[enemy.kind]))
            player.charge = min(SPECIAL_KILLS, player.charge + 1)

    hitbox = player.sword_hitbox()
    for enemy in enemies:
        if not enemy.alive:
            continue
        box = enemy.box()
        if hitbox and id(enemy) not in player.swing_hits and overlap(hitbox, box):
            player.swing_hits.add(id(enemy))
            damage(enemy, SWORD_DAMAGE, player.x + player.w / 2)
        for e in effects:
            if e.kind in ("fire", "ice") and not e.hostile and e.t < e.life and overlap((e.x - 4, e.y - 4, 8, 8), box):
                color = FIRE if e.kind == "fire" else ICE
                damage(enemy, WEAK_DAMAGE if color == enemy.weak else OTHER_DAMAGE, e.x - e.vx)
                e.life = 0  # spent
                effects.append(Effect("burst", e.x, e.y, life=0.3, color=color))
        if enemy.alive and not player.invulnerable and overlap(player.box(), box):
            player.take_hit(enemy.centre()[0])
            break  # only one hit per frame
    for e in effects:  # the dragon's breath
        if e.hostile and e.t < e.life and not player.invulnerable and overlap((e.x - 4, e.y - 4, 8, 8), player.box()):
            player.take_hit(e.x - e.vx)
            e.life = 0
            effects.append(Effect("burst", e.x, e.y, life=0.3, color=FIRE if e.kind == "fire" else ICE))


class Player:
    def __init__(self, room, forms=(), form="human", charge=0):
        row = next(r for r, line in enumerate(room) if "S" in line)
        self.spawn_point = (room[row].index("S") * TILE + TILE / 2, (row + 1) * TILE)  # centre-bottom
        self.forms = set(forms)   # animals absorbed so far
        self.form = form
        self.hearts = HEARTS
        self.charge = charge      # kills towards the lightning special
        self.reset()

    @property
    def w(self):
        return FORMS[self.form]["w"]

    @property
    def h(self):
        return FORMS[self.form]["h"]

    @property
    def alive(self):
        return self.hearts > 0

    @property
    def can_shift(self):
        return bool(self.forms)

    def reset(self):
        cx, bottom = self.spawn_point
        self.x, self.y = cx - self.w / 2, bottom - self.h
        self.vx = self.vy = 0.0
        self.facing_right = True
        self.on_ground = False
        self.since_ground = 0.0
        self.jump_buffer = 0.0
        self.air_jumps = 0
        self.swing = None         # current sword swing: tuple of (seconds, pose)
        self.swing_time = 0.0
        self.combo_step = 0       # index of the next ground swing in COMBO
        self.since_swing = 99.0
        self.queued = False
        self.swing_hits = set()   # enemies this swing already hit
        self.walk_time = 0.0
        self.cooldown = 0.0
        self.shot_time = 0.0      # mouth-open / casting pose after a shot
        self.wants_shot = None    # "ice" or "fire"; read and cleared by the game loop
        self.invulnerable = 0.0
        self.knock = 0.0          # knockback x velocity, overrides the stick while set
        self.special_time = 0.0   # strike pose remaining
        self.dance_time = 0.0     # crab dance remaining
        self.howl_time = 0.0      # fox howl remaining
        self.wants_howl = False   # read and cleared by the game loop (spawns the flames)
        self.smashed = []         # cracked tiles the mammoth broke this frame (loop clears them)
        self.wants_strike = False # Storm Walker: chain lightning, read by the loop
        self.dashed_from = None   # Storm Walker: where the last dash started (for its trail)
        self.roar_time = 0.0

    def box(self):
        return (self.x, self.y, self.w, self.h)

    def take_hit(self, from_x):
        self.hearts -= 1
        self.invulnerable = INVULNERABLE_TIME
        away = 1 if self.x + self.w / 2 >= from_x else -1
        self.knock = away * HURT_KNOCKBACK[0]
        self.vy = HURT_KNOCKBACK[1]
        self.swing = None

    def set_form(self, room, form):
        """Change form around the same feet. Returns False if it wouldn't fit."""
        if form == self.form:
            return True
        w, h = FORMS[form]["w"], FORMS[form]["h"]
        x, y = self.x + (self.w - w) / 2, self.y + self.h - h
        # On a slope a wider body dips into the hill; lift it up to STEP_UP px to clear it.
        lift = next((d for d in range(STEP_UP + 1) if box_free(room, x, y - d, w, h)), None)
        if lift is None:
            return False
        y -= lift
        self.form, self.x, self.y = form, x, y
        self.swing = None
        self.vy = min(self.vy, 0.0)
        return True

    def dash(self, room):
        """Storm Walker: blink forward, phasing through anything; lands on the farthest free spot."""
        sign = 1 if self.facing_right else -1
        for d in range(DASH_DISTANCE, 0, -4):
            x = self.x + sign * d
            if 0 <= x <= COLS * TILE - self.w + (TILE if sign > 0 else 0) and box_free(room, min(x, COLS * TILE - self.w), self.y, self.w, self.h):
                self.x = x
                self.vy = min(self.vy, 0.0)
                return True
        return False

    def cycle_form(self, room):
        """C: next form you own, skipping any that wouldn't fit here."""
        owned = [f for f in FORM_ORDER if f == "human" or f in self.forms]
        start = owned.index(self.form)
        for step in range(1, len(owned)):
            if self.set_form(room, owned[(start + step) % len(owned)]):
                return

    def sword_hitbox(self):
        box = SWORD_HITBOX.get(self.pose()) if self.swing is not None else None
        if box is None:
            return None
        dx, dy, w, h = box
        x = self.x + dx if self.facing_right else self.x + self.w - dx - w
        return (x, self.y + dy, w, h)

    def hits(self, room, x, y, feet=None):
        """Blocking tiles for the box at (x, y). With feet (previous bottom edge),
        one-way ledges whose top is at or below the feet block too."""
        c0, c1 = math.floor(x / TILE), math.floor((x + self.w - 1) / TILE)
        r0, r1 = math.floor(y / TILE), math.floor((y + self.h - 1) / TILE)
        return [(c, r) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)
                if tile_at(room, c, r) in SOLID
                or (tile_at(room, c, r) == LOW_OVERHANG and y < r * TILE + OVERHANG_DEPTH)
                or (feet is not None and tile_at(room, c, r) in ONE_WAY and r * TILE >= feet)]

    def update_sword(self, dt, pressed):
        if self.swing is not None:
            self.swing_time += dt
            length = sum(t for t, _ in self.swing)
            if pressed & BUTTON_B and self.swing_time >= length * COMBO_ACCEPT:
                self.queued = True
            if self.swing_time >= length:
                self.swing, self.since_swing = None, 0.0
                if self.queued:
                    self.start_swing()
            return
        self.since_swing += dt
        if pressed & BUTTON_B:
            if self.since_swing > COMBO_WINDOW:
                self.combo_step = 0
            self.start_swing()

    def start_swing(self):
        self.queued = False
        self.swing_time = 0.0
        self.swing_hits = set()
        if self.on_ground:
            self.swing = COMBO[self.combo_step]
            self.combo_step = (self.combo_step + 1) % len(COMBO)
        else:
            self.swing = AIR_SLASH

    def update(self, room, dt, stick_x, pressed, held, frozen=False, stick_y=0):
        if frozen:  # absorbing: rooted to the spot
            stick_x = 0
            pressed &= ~(BUTTON_A | BUTTON_B | BUTTON_C)
        # Emotes: the crab dances on A; the fox howls fire on stick-up + A (plain A jumps).
        self.dance_time = max(0.0, self.dance_time - dt)
        self.howl_time = max(0.0, self.howl_time - dt)
        if pressed & BUTTON_A and self.form == "crab":
            self.dance_time = DANCE_TIME
        if pressed & BUTTON_A and self.form == "fox" and self.on_ground and stick_y < -STICK_DEADZONE:
            self.howl_time = HOWL_TIME
            self.wants_howl = True
            pressed &= ~BUTTON_A
        if self.dance_time or self.howl_time:
            stick_x = 0
        if self.form == "storm":
            if pressed & BUTTON_C and not self.cooldown:  # electric dash
                start = self.x
                if self.dash(room):
                    self.cooldown = DASH_COOLDOWN
                    self.dashed_from = start
            if pressed & BUTTON_B and not self.special_time:  # chain lightning
                self.wants_strike = True
                self.special_time = STORM_COOLDOWN
            pressed &= ~(BUTTON_B | BUTTON_C)
        elif pressed & BUTTON_C and self.swing is None:
            self.cycle_form(room)
        stats = FORMS[self.form]
        push = 0.0 if abs(stick_x) < STICK_DEADZONE else stick_x / STICK_FULL
        self.vx = stats["speed"] * max(-1.0, min(1.0, push))
        if self.vx and self.swing is None:
            self.facing_right = self.vx > 0
        self.invulnerable = max(0.0, self.invulnerable - dt)
        if self.knock:  # knocked back: no steering until it fades
            self.vx = self.knock
            self.knock = 0.0 if abs(self.knock) < 20 else self.knock * 0.02 ** dt

        # Jump with coyote time, input buffering and variable height; the fox jumps again in the air.
        if stats["jump"] is not None:
            self.jump_buffer = JUMP_BUFFER if pressed & BUTTON_A else max(0.0, self.jump_buffer - dt)
            self.since_ground = 0.0 if self.on_ground else self.since_ground + dt
            if self.on_ground:
                self.air_jumps = stats["air_jumps"]
            if self.jump_buffer and self.since_ground <= COYOTE_TIME:
                self.vy = stats["jump"]
                self.jump_buffer = 0.0
                self.since_ground = COYOTE_TIME + 1
            elif pressed & BUTTON_A and self.since_ground > COYOTE_TIME and self.air_jumps:
                self.vy = DOUBLE_JUMP_VELOCITY
                self.air_jumps -= 1
                self.jump_buffer = 0.0
            if self.vy < 0 and not held & BUTTON_A:
                self.vy *= JUMP_CUT
        self.vy = min(MAX_FALL, self.vy + GRAVITY * dt)

        # Attacks: the human swings the sword, the crab spits ice, the fox shoots fire.
        self.cooldown = max(0.0, self.cooldown - dt)
        self.shot_time = max(0.0, self.shot_time - dt)
        self.special_time = max(0.0, self.special_time - dt)
        if self.form == "storm":
            pass
        elif self.form == "human":
            self.update_sword(dt, pressed)
            if self.swing is not None:
                self.vx *= ATTACK_MOVE
                if self.pose() == LUNGE_POSE:
                    self.vx = LUNGE_SPEED if self.facing_right else -LUNGE_SPEED
        elif self.form == "mammoth":
            self.roar_time = max(0.0, self.roar_time - dt)
            if pressed & BUTTON_B:  # roar: just for show
                self.roar_time = 0.5
        elif pressed & BUTTON_B and not self.cooldown:
            self.cooldown = SHARD_COOLDOWN if self.form == "crab" else FIREBALL_COOLDOWN
            self.shot_time = 0.15
            self.wants_shot = "ice" if self.form == "crab" else "fire"

        # Horizontal: rock blocks, but small lips (e.g. a slope's top) are stepped up.
        was_grounded = self.on_ground
        nx = self.x + self.vx * dt
        hit = self.hits(room, nx, self.y)
        if self.form == "mammoth":  # walking into cracked rock smashes it
            cracked = [(c, r) for c, r in hit if tile_at(room, c, r) == CRACKED]
            if cracked:
                self.smashed.extend(cracked)
                hit = [t for t in hit if t not in cracked]
        if hit and was_grounded and not self.hits(room, nx, self.y - STEP_UP):
            self.y -= next(s for s in range(1, STEP_UP + 1) if not self.hits(room, nx, self.y - s))
            hit = []
        if hit:
            nx = min(c for c, _ in hit) * TILE - self.w if self.vx > 0 else (max(c for c, _ in hit) + 1) * TILE
        self.x = nx

        # Vertical against rock and one-way ledges.
        feet_before = self.y + self.h
        ny = self.y + self.vy * dt
        feet = feet_before if self.vy >= 0 else None
        hit = self.hits(room, self.x, ny, feet)
        self.on_ground = False
        if hit:
            if self.vy > 0:
                ny = min(r for _, r in hit) * TILE - self.h
                self.on_ground = True
            else:
                ny = (max(r for _, r in hit) + 1) * TILE
            self.vy = 0.0
        self.y = ny
        # Sub-pixel gravity steps don't reach the floor; probe 1 px down so standing stays grounded.
        if not self.on_ground and feet is not None:
            floor = self.hits(room, self.x, self.y + 1, feet)
            if floor:
                self.on_ground = True
                self.vy = 0.0
                self.y = min(r for _, r in floor) * TILE - self.h  # snap, so rounding can't bob

        # Slopes: the centre of the feet follows the surface line; downhill it sticks.
        cx = self.x + self.w / 2
        if self.vy >= 0:
            feet_now = self.y + self.h
            catch = 4 + abs(self.vx * dt) + max(0.0, feet_now - feet_before)
            reach = SLOPE_SNAP if was_grounded else 0.0
            for row in range(math.floor((feet_now - catch) / TILE), math.floor((feet_now + reach) / TILE) + 1):
                s = shape_y(room, cx, row, FLOOR_SHAPES, True)
                if s is not None and feet_now - catch <= s <= feet_now + reach:
                    if not self.on_ground or s < feet_now:
                        self.y = s - self.h
                    self.vy = 0.0
                    self.on_ground = True
                    break
        # Sloped ceilings stop the head.
        for row in (math.floor(self.y / TILE), math.floor(self.y / TILE) - 1):
            s = shape_y(room, cx, row, CEIL_SHAPES, False)
            if s is not None and self.y < s <= self.y + self.h / 2:
                self.y = s
                self.vy = max(self.vy, 0.0)

        self.walk_time = self.walk_time + dt if self.on_ground and self.vx else 0.0
        if self.y > ROWS * TILE:
            self.reset()
        return self.x >= COLS * TILE  # True once through the room's exit

    def pose(self):
        if self.special_time and self.form in ("human", "storm"):
            return 17  # hand up, palm glowing with lightning
        if self.swing is not None:
            elapsed = self.swing_time
            for duration, pose in self.swing:
                if elapsed < duration:
                    return pose
                elapsed -= duration
            return self.swing[-1][1]
        if not self.on_ground:
            return 3
        if self.walk_time:
            return 1 + int(self.walk_time / WALK_FRAME_TIME) % 2
        return 0

    def sprite(self):
        hidden = self.invulnerable and int(self.invulnerable / 0.1) % 2  # blink while invulnerable
        step = int(self.walk_time / 0.1) % 2
        if self.form == "crab":
            if self.dance_time:  # bit 3: dancing; the step bit swaps which claw is up
                step = int(self.dance_time / 0.12) % 2
            kind = SPRITE_PLAYER_CRAB
            flags = int(self.facing_right) | step << 1 | (4 if self.shot_time else 0) | (8 if self.dance_time else 0)
        elif self.form == "mammoth":
            kind = SPRITE_PLAYER_MAMMOTH
            flags = int(self.facing_right) | step << 1 | (4 if not self.on_ground else 0) | (8 if self.roar_time else 0)
        elif self.form == "fox":
            kind = SPRITE_PLAYER_FOX
            flags = (int(self.facing_right) | step << 1 | (4 if not self.on_ground else 0)
                     | (8 if self.shot_time else 0) | (16 if self.howl_time else 0))
        else:
            kind, flags = SPRITE_PLAYER, (self.pose() << 1) | (1 if self.facing_right else 0)
            if self.form == "storm":
                flags |= STORM_FLAG
        return struct.pack("<BhhB", SPRITE_NONE if hidden else kind, round(self.x), round(self.y), flags)


room_index = START_STAGE - 1
room = list(ROOMS[room_index])  # a copy: freezing and burning edit it
falls = ROOM_WATERFALL[room_index]
waterfall = Waterfall(*falls) if falls else None
dragon = Dragon(*ROOM_BOSS[room_index]) if ROOM_BOSS[room_index] else None
player = Player(room, [f for f in ROOM_NEEDS[:room_index] if f])
enemies = []
effects = []
burning = {}                  # (col, row) -> time it catches fire
absorb_progress = 0.0
previous_buttons = 0
last_time = time.monotonic()
stats_time, stats_frames = last_time, 0
timings = [0.0, 0.0]  # seconds spent in input read / frame draw since last report
peak_motion = 0.0     # strongest jolt (mg) since last report, for tuning the shake
last_accel = None     # previous frame's acceleration, to measure jolts as change
next_inputs = ""      # controls returned by the last game_frame; "" means read them directly
jolts = []            # times of recent hard jolts
jolt_armed = True     # the reading must settle between jolts so one bump counts once


def detect_shake(magnitude, now):
    """True on SHAKE_JOLTS hard jolts within SHAKE_WINDOW: a deliberate, strong shake."""
    global jolt_armed
    if magnitude > SHAKE_THRESHOLD_MG and jolt_armed:
        jolt_armed = False
        jolts.append(now)
    elif magnitude < SHAKE_THRESHOLD_MG / 2:
        jolt_armed = True
    jolts[:] = [t for t in jolts if now - t <= SHAKE_WINDOW]
    if len(jolts) >= SHAKE_JOLTS:
        jolts.clear()
        return True
    return False


def send_room():
    for row, line in enumerate(room):
        Bridge.call("game_room_row", row, line.encode())
    Bridge.call("game_room_draw")


def set_tile(col, row, ch):
    room[row] = room[row][:col] + ch + room[row][col + 1:]
    Bridge.call("game_set_tile", col, row, ord(ch))


def spawn_enemies():
    return [Enemy(kind, col, row, room) for kind, col, row in ROOM_ENEMIES[room_index]]


def enter_room(index):
    """Load a room fresh. Also used to restart it after running out of hearts."""
    global room_index, room, player, enemies, waterfall, dragon
    room_index = index % len(ROOMS)  # after the last stage, back to the first
    room = list(ROOMS[room_index])
    falls = ROOM_WATERFALL[room_index]
    waterfall = Waterfall(*falls) if falls else None
    dragon = Dragon(*ROOM_BOSS[room_index]) if ROOM_BOSS[room_index] else None
    if storm_run:  # the Storm Walker keeps their powers on every stage
        player = Player(room, (), "storm")
    elif room_index == 0:  # back at stage 1: the hero starts over as plain human
        player = Player(room)
    else:  # forms and the special's charge carry over
        player = Player(room, player.forms, player.form, player.charge)
    enemies = spawn_enemies()
    effects.clear()
    burning.clear()
    print(f"Entering stage {room_index + 1}")
    send_room()


enemies = spawn_enemies()


def ignite(col, row, now):
    if (col, row) not in burning and tile_at(room, col, row) in BURNABLE:
        burning[(col, row)] = now


def update_fire(now):
    """Burning tiles turn to flame and ash, and set their burnable neighbours alight."""
    for (col, row), due in list(burning.items()):
        if due > now:
            continue
        del burning[(col, row)]
        ch = tile_at(room, col, row)
        if ch not in BURNABLE:
            continue
        set_tile(col, row, ".")
        effects.append(Effect("flame", col * TILE + TILE / 2, row * TILE + TILE - 2, life=FLAME_TIME))
        for dc, dr in ((1, 0), (-1, 0), (0, -1), (0, 1), (1, -1), (-1, -1)):
            if tile_at(room, col + dc, row + dr) in BURNABLE:
                ignite(col + dc, row + dr, now + BURN_SPREAD[tile_at(room, col + dc, row + dr)])
    del effects[:-MAX_EFFECTS]


def freeze_waterfall():
    waterfall.frozen = True
    for r, line in enumerate(room):
        room[r] = line.replace(WATER_TILE, "I")
    for y in range(waterfall.y + 20, waterfall.y + waterfall.h, 60):
        effects.append(Effect("burst", waterfall.x + waterfall.w / 2, y, life=0.3, color=ICE))
    del effects[:-MAX_EFFECTS]
    print("The waterfall froze: walk across the ice.")
    send_room()  # redraw the pool as ice


def release_special():
    """Lightning from the top of the screen onto every enemy; they all fall."""
    player.charge = 0
    player.special_time = SPECIAL_POSE_TIME
    effects.clear()
    for enemy in enemies:
        if not enemy.alive:
            continue
        cx, cy = enemy.centre()
        enemy.hurt(enemy.hp, cx)
        length = min(252, max(8, int(cy) - TILE))
        length -= length % 4
        effects.append(Effect("bolt", cx, cy - length, life=BOLT_TIME, length=length))
        effects.append(Effect("burst", cx, cy, life=0.3, color=LIGHTNING))
    if not any(e.kind == "bolt" for e in effects):  # nothing to hit: bolts still crash down around the hero
        for dx in (-50, 0, 50):
            x = player.x + player.w / 2 + dx
            ground = probe(room, x, player.y, 2, 120)
            bottom = int(ground if ground is not None else player.y + player.h)
            length = min(252, max(8, bottom - TILE))
            length -= length % 4
            effects.append(Effect("bolt", x, bottom - length, life=BOLT_TIME, length=length))
            effects.append(Effect("burst", x, bottom - 4, life=0.3, color=LIGHTNING))
    del effects[:-MAX_EFFECTS]
    print("Lightning special released.")


free_progress = 0.0
ending = False            # the prisoner is free: banner up, C to replay as the Storm Walker
storm_run = False         # replaying as the Storm Walker


def storm_strike():
    """Chain lightning from the sky: every enemy in range, the dragon (one hit), the
    waterfall (evaporates) and the nearest burnable obstacle ahead (catches fire)."""
    cx, cy = player.x + player.w / 2, player.y + player.h / 2
    targets = sorted((e for e in enemies if e.alive and math.hypot(e.centre()[0] - cx, e.centre()[1] - cy) < STORM_STRIKE_RANGE),
                     key=lambda e: abs(e.centre()[0] - cx))
    spots = []
    for enemy in targets:
        ex, ey = enemy.centre()
        enemy.hurt(enemy.hp, ex)
        spots.append((ex, ey))
    if dragon and dragon.alive and dragon.dying is None:
        dragon.hp, dragon.dying = 0, 0.0
        spots.append((dragon.x + DRAGON_W / 2, dragon.y + 40))
    if waterfall and not waterfall.frozen and abs(waterfall.x - cx) < 300:
        evaporate_waterfall()
        spots.append((waterfall.x + waterfall.w / 2, waterfall.y + waterfall.h - 10))
    sign = 1 if player.facing_right else -1
    row = math.floor(cy / TILE)
    for d in range(0, 160, 10):
        col = math.floor((cx + sign * d) / TILE)
        hit = next((r for r in range(row - 3, row + 2) if tile_at(room, col, r) in BURNABLE), None)
        if hit is not None:
            ignite(col, hit, time.monotonic())
            spots.append((col * TILE + TILE / 2, hit * TILE + TILE / 2))
            break
    for x, y in spots[:6]:
        length = min(252, max(8, int(y) - TILE))
        length -= length % 4
        effects.append(Effect("bolt", x, y - length, life=BOLT_TIME, length=length))
        effects.append(Effect("burst", x, y, life=0.3, color=LIGHTNING))
    if not spots:  # a bolt in front anyway
        effects.append(Effect("bolt", cx + sign * 40, TILE, life=BOLT_TIME, length=max(8, int(player.y + player.h) - TILE - 8)))
    del effects[:-MAX_EFFECTS]


def evaporate_waterfall():
    """Storm lightning boils the waterfall and the pool away (the pool becomes a dry pit)."""
    waterfall.frozen = True   # no more current
    waterfall.gone = True
    for r, line in enumerate(room):
        room[r] = line.replace(WATER_TILE, ".")
    send_room()


def start_storm_run():
    global storm_run, ending, room_index, room, player, enemies, waterfall, dragon
    storm_run, ending = True, False
    room_index = 0
    room = list(ROOMS[0])
    waterfall, dragon = None, None
    player = Player(room, (), "storm")
    enemies = spawn_enemies()
    effects.clear()
    burning.clear()
    print("Playing again as the Storm Walker.")
    send_room()


def near_cage(player):
    return room_index == CAGE_ROOM and not ending and overlap(player.box(), (CAGE_X - 14, CAGE_Y - 10, CAGE_W + 28, CAGE_H + 10))


def body_under(player):
    """A dead animal the hero is over, if it's one they haven't absorbed yet."""
    return next((e for e in enemies if e.corpse and not e.alive and e.kind not in player.forms
                 and overlap(player.box(), e.absorb_box())), None)


def hud_mode():
    if player.form == "storm":
        return HUD_STORM
    if room_index == CAGE_ROOM and not ending:
        return HUD_PRISONER
    if dragon and dragon.alive:
        return HUD_BOSS
    if EXIT_LOCKED and player.x > COLS * TILE - 90:
        return {"crab": HUD_NEED_CRAB, "fox": HUD_NEED_FOX, "mammoth": HUD_NEED_MAMMOTH}[ROOM_NEEDS[room_index]]
    if player.form == "mammoth":
        return HUD_MAMMOTH
    if player.form == "crab":
        return HUD_CRAB
    if player.form == "fox":
        return HUD_FOX
    return HUD_HUMAN_CAN_SHIFT if player.can_shift else HUD_HUMAN


def frame_sprites():
    # Fixed slots first (HUD, hearts, prompt, waterfall, hero, one per enemy even once
    # dead) so only effects come and go at the end and nothing else shifts slot.
    hud = struct.pack("<BhhB", SPRITE_HUD, 6, 3, hud_mode())
    hearts = struct.pack("<BhhB", SPRITE_HEARTS, 412, 3, max(0, player.hearts))
    body = body_under(player)
    if near_cage(player):  # "HOLD STICK: FREE" above the cage
        prompt = struct.pack("<BhhB", SPRITE_PROMPT, CAGE_X + CAGE_W // 2, CAGE_Y - 26,
                             16 | min(10, int(free_progress / FREE_TIME * 10)))
    elif body:  # "HOLD STICK: ABSORB" above the body, with a progress bar
        cx = max(60, min(COLS * TILE - 60, round(body.x + body.w / 2)))
        prompt = struct.pack("<BhhB", SPRITE_PROMPT, cx, max(22, round(body.y) - 34),
                             min(10, int(absorb_progress / ABSORB_TIME * 10)))
    else:
        prompt = struct.pack("<BhhB", SPRITE_NONE, 0, 0, 0)
    falls = waterfall.sprite() if waterfall else struct.pack("<BhhB", SPRITE_NONE, 0, 0, 0)
    ready = player.charge >= SPECIAL_KILLS
    blink = ready and int(time.monotonic() / 0.35) % 2
    animal = player.form != "human"  # lightning is the hero's alone: pips dim, no SHAKE!
    special = struct.pack("<BhhB", SPRITE_SPECIAL, 330, 3,
                          player.charge | (4 if blink and not animal else 0) | (8 if animal else 0))
    if dragon:
        boss = dragon.sprite()
    elif room_index == CAGE_ROOM and not storm_run:  # the cage, then the ending banner
        boss = struct.pack("<BhhB", SPRITE_BANNER if ending else SPRITE_CAGE,
                           90 if ending else CAGE_X, 100 if ending else CAGE_Y, 0)
    else:
        boss = struct.pack("<BhhB", SPRITE_NONE, 0, 0, 0)
    return (hud + hearts + special + prompt + falls + boss + player.sprite() + b"".join(e.sprite() for e in enemies)
            + b"".join(e.sprite() for e in effects))


def step_game(dt, now, stick_x, pressed, held, shake=False, stick_y=0):
    """One frame of game rules (no Bridge I/O except room/tile updates)."""
    global absorb_progress, EXIT_LOCKED, free_progress, ending
    if ending:  # the prisoner is free: C plays again as them
        if pressed & BUTTON_C:
            start_storm_run()
        return
    need = ROOM_NEEDS[room_index]
    EXIT_LOCKED = not storm_run and ((need is not None and need not in player.forms) or bool(dragon and dragon.alive))
    if near_cage(player) and held & BUTTON_STICK:  # free the prisoner
        free_progress += dt
        if free_progress >= FREE_TIME:
            ending = True
            for k in range(6):
                effects.append(Effect("burst", CAGE_X + 6 + k * 6, CAGE_Y + 10 + (k % 3) * 10, life=0.3, color=LIGHTNING))
            print("The prisoner is free. Press C to play again as the Storm Walker.")
            return
    else:
        free_progress = 0.0
    # Absorb: hold the stick click over a body; you take that animal's form.
    body = body_under(player)
    absorbing = bool(body) and bool(held & BUTTON_STICK)
    absorb_progress = absorb_progress + dt if absorbing else 0.0
    if body and absorb_progress >= ABSORB_TIME:
        body.corpse = False
        absorb_progress = 0.0
        player.forms.add(body.kind)
        player.set_form(room, body.kind)
        effects.append(Effect("burst", player.x + player.w / 2, player.y + player.h / 2, life=0.3,
                              color=ESSENCE_COLOR[body.kind]))
        print(f"Absorbed a {body.kind}: C switches form.")
    if shake and player.form == "human" and player.charge >= SPECIAL_KILLS:
        release_special()  # the hero's own power (the dragon is immune)
    if player.update(room, dt, stick_x, pressed, held, frozen=absorbing, stick_y=stick_y):
        enter_room(room_index + 1)
        return
    for col, row in player.smashed:  # the mammoth charged into boulders: the whole pile above crumbles
        top = row
        while tile_at(room, col, top - 1) == CRACKED:
            top -= 1
        for r in range(top, row + 1):
            if tile_at(room, col, r) == CRACKED:
                set_tile(col, r, ".")
                effects.append(Effect("burst", col * TILE + TILE / 2, r * TILE + TILE / 2, life=0.3, color=0))
    player.smashed.clear()
    if player.form == "mammoth" and player.roar_time > 0.45:  # roar: a green shockwave
        effects.append(Effect("burst", player.x + (player.w if player.facing_right else 0), player.y + 6,
                              life=0.3, color=EARTH))
        player.roar_time = 0.44
    if player.wants_strike:
        player.wants_strike = False
        storm_strike()
    if player.dashed_from is not None:  # a crackling trail where the dash went
        a, b = sorted((player.dashed_from, player.x))
        for x in range(int(a), int(b), 30):
            effects.append(Effect("burst", x + 6, player.y + player.h / 2, life=0.25, color=LIGHTNING))
        player.dashed_from = None
        del effects[:-MAX_EFFECTS]
    if player.wants_howl:  # an arc of fire above the howling fox
        player.wants_howl = False
        head_x = player.x + (player.w if player.facing_right else 0)
        for dx, dy in ((-10, -2), (0, -10), (10, -2)):
            effects.append(Effect("flame", head_x + dx, player.y + dy, life=0.5))
        effects.append(Effect("burst", head_x, player.y - 6, life=0.3, color=FIRE))
    if waterfall:
        waterfall.t += dt
        if not waterfall.frozen and overlap(player.box(), waterfall.rect()):  # dragged down
            player.y += WATERFALL_PULL * dt
            player.vy = max(player.vy, WATERFALL_PULL)
    if in_water(room, player.box()):  # splash: lose a heart, back to the start of the stage
        effects.append(Effect("burst", player.x + player.w / 2, player.y, life=0.3, color=WATER))
        player.hearts -= 1
        player.reset()
        player.invulnerable = INVULNERABLE_TIME
    if player.wants_shot:
        kind, player.wants_shot = player.wants_shot, None
        sign = 1 if player.facing_right else -1
        speed, reach = (SHARD_SPEED, SHARD_RANGE) if kind == "ice" else (FIREBALL_SPEED, FIREBALL_RANGE)
        mouth = player.x + (player.w + 3 if player.facing_right else -3)
        reach *= ROOM_RANGE[room_index]
        effects.append(Effect(kind, mouth, player.y + player.h / 2 - 1, vx=sign * speed, life=reach / speed,
                              right=player.facing_right))
    for enemy in enemies:
        enemy.update(room, dt)
    if dragon:
        dragon.update(dt, player, effects)
        if dragon.alive:
            for e in effects:  # the hero's fire and ice against the dragon
                if e.kind in ("fire", "ice") and not e.hostile and e.t < e.life \
                        and overlap((e.x - 4, e.y - 4, 8, 8), dragon.hitbox()):
                    effects.append(Effect("burst", e.x, e.y, life=0.3, color=dragon.struck(e.kind)))
                    e.life = 0
            if dragon.dying is None and not player.invulnerable and overlap(player.box(), dragon.hitbox()):
                player.take_hit(dragon.x + DRAGON_W / 2)
    spawned, ignited = [], []
    effects[:] = [e for e in effects if e.update(room, dt, spawned, ignited)] + spawned
    for col, row in ignited:
        ignite(col, row, now)
    update_fire(now)
    if waterfall and not waterfall.frozen and any(
            e.kind == "ice" and overlap((e.x - 4, e.y - 4, 8, 8), waterfall.rect()) for e in effects):
        freeze_waterfall()
    resolve_combat(player, enemies, effects)
    del effects[:-MAX_EFFECTS]
    if not player.alive:
        print(f"Out of hearts in stage {room_index + 1}; restarting it.")
        enter_room(room_index)


def loop():
    global previous_buttons, last_time, stats_time, stats_frames, next_inputs, peak_motion, last_accel
    try:
        t0 = time.monotonic()
        if not next_inputs:  # first frame, or the room had to be resent
            next_inputs = Bridge.call("arcade_read_inputs")
        inputs = json.loads(next_inputs)
        next_inputs = ""
        timings[0] += time.monotonic() - t0
        if inputs.get("video", 0):
            time.sleep(0.5)
            return
        stick_x, stick_y, held, ax, ay, az, connected = controls(inputs)
        pressed = held & ~previous_buttons
        previous_buttons = held
        if connected & 4:  # a strong shake: several hard jolts in quick succession
            # A jolt is how much the acceleration changed since last frame: near zero when still,
            # however the console is tilted, and large for even a mild shake.
            px, py, pz = last_accel or (ax, ay, az)
            last_accel = (ax, ay, az)
            motion = math.sqrt((ax - px) ** 2 + (ay - py) ** 2 + (az - pz) ** 2)
            peak_motion = max(peak_motion, motion)
            shake = detect_shake(motion, time.monotonic())
        else:  # no Movement module: the stick click releases it instead
            shake = bool(pressed & BUTTON_STICK) and body_under(player) is None

        now = time.monotonic()
        dt = min(MAX_DT, now - last_time)
        last_time = now
        step_game(dt, now, stick_x, pressed, held, shake, stick_y)

        # Keep sending frames every loop; the sketch blanks the game after 1.5 s without one.
        # The reply carries the controls for the next loop (one round trip per frame).
        t0 = time.monotonic()
        next_inputs = Bridge.call("game_frame", frame_sprites())
        timings[1] += time.monotonic() - t0
        if not next_inputs:
            send_room()
            next_inputs = Bridge.call("game_frame", frame_sprites())
    except Exception as error:
        print(f"Arcade connection/input error: {error}")
        time.sleep(1)
        return

    stats_frames += 1
    if now - stats_time >= 1:
        print(f"loop {stats_frames / (now - stats_time):.1f} Hz, connected={connected}, "
              f"input {timings[0] * 1000 / stats_frames:.1f} ms, draw {timings[1] * 1000 / stats_frames:.1f} ms, "
              f"peak motion {peak_motion:.0f} mg")
        stats_time, stats_frames = now, 0
        peak_motion = 0.0
        timings[:] = [0.0, 0.0]


if __name__ == "__main__":
    print("Essence Thief: stick moves, A jumps, B attacks, C shifts form; hold the stick click to absorb.")
    App.run(user_loop=loop)
